package learning
import "context"
func (i *Individual) trainChemicalEpisode(ctx context.Context, input [][]float64, target []float64) (StepResult, error) {return i.trainer.Step(ctx, input, target)}
