package main

import (
	"context"
	"fmt"
	"math"
	"os"

	"github.com/TimLai666/coimnet/learning"
	"github.com/TimLai666/coimnet/modulation"
)

var auditOperations = []string{"from", "step", "from", "step", "from"}

func runMatrix(ctx context.Context) ([]matrixRecord, error) {
	var records []matrixRecord
	for _, core := range []string{"continuous", "lif"} {
		for _, filled := range []int{0, 1, 3, 4} {
			for _, delay := range []int{2, 5} {
				for _, window := range []int{0, 3, 5} {
					for _, segment := range []int{1, 2, 5, 11} {
						key := caseKey{Core: core, Filled: filled, Delay: delay, Window: window, Segment: segment}
						record, err := auditMatrixCase(ctx, key)
						if err != nil {
							return nil, fmt.Errorf("matrix %+v: %w", key, err)
						}
						records = append(records, record)
					}
				}
			}
		}
	}
	return records, nil
}

func auditMatrixCase(ctx context.Context, key caseKey) (matrixRecord, error) {
	var zero matrixRecord
	if err := auditContextError(ctx); err != nil {
		return zero, err
	}
	fx, err := auditFixture(key)
	if err != nil {
		return zero, err
	}
	originalConfig, err := auditCloneConfig(fx.Config)
	if err != nil {
		return zero, err
	}
	originalParameters := auditCloneParameters(fx.Parameters)
	originalInput := auditCloneRows(fx.Input)
	originalUpstream := auditCloneRows(fx.Upstream)
	originalTarget := append([]float64(nil), fx.Target...)
	full, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, false))
	if err != nil {
		return zero, fmt.Errorf("full trainer: %w", err)
	}
	recompute, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, true))
	if err != nil {
		_ = full.Close()
		return zero, fmt.Errorf("recompute trainer: %w", err)
	}
	defer func() { _ = full.Close() }()
	defer func() { _ = recompute.Close() }()
	network, err := learning.NewNetwork(fx.Config)
	if err != nil {
		return zero, fmt.Errorf("network: %w", err)
	}
	publicGradient, err := network.LossGradientFrom(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), auditCloneRows(fx.Upstream), key.Window)
	if err != nil {
		return zero, fmt.Errorf("public gradient: %w", err)
	}
	if err := auditGradientFinite(publicGradient); err != nil {
		return zero, fmt.Errorf("public gradient finite: %w", err)
	}
	publicAgain, err := network.LossGradientFrom(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), auditCloneRows(fx.Upstream), key.Window)
	if err != nil {
		return zero, fmt.Errorf("repeated public gradient: %w", err)
	}
	if err := equal(publicGradient, publicAgain); err != nil {
		return zero, fmt.Errorf("repeated public gradient differs: %w", err)
	}
	firstGradient := auditFlatGradient(publicGradient)
	if len(firstGradient) == 0 || !auditAnyNonzero(firstGradient) {
		return zero, fmt.Errorf("public parameter gradient is zero")
	}
	_, mseGradient, err := network.LossGradient(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), append([]float64(nil), fx.Target...), key.Window)
	if err != nil {
		return zero, fmt.Errorf("public MSE gradient: %w", err)
	}
	if err := auditGradientFinite(mseGradient); err != nil {
		return zero, fmt.Errorf("public MSE gradient finite: %w", err)
	}
	mseFlat := auditFlatGradient(mseGradient)
	if len(mseFlat) != len(firstGradient) {
		return zero, fmt.Errorf("public MSE gradient length %d, upstream gradient length %d", len(mseFlat), len(firstGradient))
	}
	firstUpdateMeanNorm := 0.0
	for index := range firstGradient {
		mean := (firstGradient[index] + mseFlat[index]) / 2
		if !auditFiniteFloat(mean) {
			return zero, fmt.Errorf("first update mean gradient[%d] is non-finite: %g", index, mean)
		}
		firstUpdateMeanNorm = math.Hypot(firstUpdateMeanNorm, mean)
		if !auditFiniteFloat(firstUpdateMeanNorm) {
			return zero, fmt.Errorf("first update mean norm is non-finite after gradient[%d]", index)
		}
	}
	firstUpdateClipped := firstUpdateMeanNorm > auditOptions(key, false).ClipNorm
	initial := full.Snapshot()
	for index, operation := range auditOperations {
		fullPrediction, err := full.PredictAll(ctx, auditCloneRows(fx.Input))
		if err != nil {
			return zero, fmt.Errorf("full prediction before %s: %w", operation, err)
		}
		recomputePrediction, err := recompute.PredictAll(ctx, auditCloneRows(fx.Input))
		if err != nil {
			return zero, fmt.Errorf("recompute prediction before %s: %w", operation, err)
		}
		if err := equal(fullPrediction, recomputePrediction); err != nil {
			return zero, fmt.Errorf("prediction before operation %d: %w", index, err)
		}
		fullResult, fullInput, fullTarget, fullUpstream, err := auditTrainerOperation(ctx, full, operation, fx)
		if err != nil {
			return zero, fmt.Errorf("full %s: %w", operation, err)
		}
		recomputeResult, recomputeInput, recomputeTarget, recomputeUpstream, err := auditTrainerOperation(ctx, recompute, operation, fx)
		if err != nil {
			return zero, fmt.Errorf("recompute %s: %w", operation, err)
		}
		if err := auditResultFinite(fullResult); err != nil {
			return zero, fmt.Errorf("full result %s finite: %w", operation, err)
		}
		if err := auditResultFinite(recomputeResult); err != nil {
			return zero, fmt.Errorf("recompute result %s finite: %w", operation, err)
		}
		if err := equal(fullResult, recomputeResult); err != nil {
			return zero, fmt.Errorf("StepResult operation %d: %w", index, err)
		}
		if err := equal(normalized(full.Snapshot()), normalized(recompute.Snapshot())); err != nil {
			return zero, fmt.Errorf("snapshot operation %d: %w", index, err)
		}
		if err := equal(fullInput, fx.Input); err != nil {
			return zero, fmt.Errorf("full %s mutated input: %w", operation, err)
		}
		if err := equal(recomputeInput, fx.Input); err != nil {
			return zero, fmt.Errorf("recompute %s mutated input: %w", operation, err)
		}
		if err := equal(fullTarget, fx.Target); err != nil {
			return zero, fmt.Errorf("full %s mutated target: %w", operation, err)
		}
		if err := equal(recomputeTarget, fx.Target); err != nil {
			return zero, fmt.Errorf("recompute %s mutated target: %w", operation, err)
		}
		if err := equal(fullUpstream, fx.Upstream); err != nil {
			return zero, fmt.Errorf("full %s mutated upstream: %w", operation, err)
		}
		if err := equal(recomputeUpstream, fx.Upstream); err != nil {
			return zero, fmt.Errorf("recompute %s mutated upstream: %w", operation, err)
		}
		if index == 0 {
			for name, snapshot := range map[string]learning.TrainingSnapshot{"full": full.Snapshot(), "recompute": recompute.Snapshot()} {
				if snapshot.Accumulator == nil || snapshot.Accumulator.Count != 1 {
					return zero, fmt.Errorf("%s first pending snapshot has accumulator %+v", name, snapshot.Accumulator)
				}
				if len(snapshot.Accumulator.Sum) != len(firstGradient) {
					return zero, fmt.Errorf("%s first pending gradient length %d, want %d", name, len(snapshot.Accumulator.Sum), len(firstGradient))
				}
				for gradientIndex := range firstGradient {
					if snapshot.Accumulator.Sum[gradientIndex] != firstGradient[gradientIndex] {
						return zero, fmt.Errorf("%s first pending gradient[%d]=%g, want %g", name, gradientIndex, snapshot.Accumulator.Sum[gradientIndex], firstGradient[gradientIndex])
					}
				}
			}
		}
	}
	finalSnapshot := full.Snapshot()
	if err := equal(normalized(finalSnapshot), normalized(recompute.Snapshot())); err != nil {
		return zero, fmt.Errorf("final snapshot: %w", err)
	}
	if finalSnapshot.Updates != 2 {
		return zero, fmt.Errorf("final snapshot updates=%d, want 2", finalSnapshot.Updates)
	}
	if finalSnapshot.Accumulator == nil || finalSnapshot.Accumulator.Count != 1 {
		return zero, fmt.Errorf("final snapshot has accumulator %+v, want count 1", finalSnapshot.Accumulator)
	}
	if err := equal(initial.Parameters, finalSnapshot.Parameters); err == nil {
		return zero, fmt.Errorf("parameters did not change after two accumulated updates")
	}
	finalPrediction, err := full.PredictAll(ctx, auditCloneRows(fx.Input))
	if err != nil {
		return zero, fmt.Errorf("final prediction: %w", err)
	}
	if err := auditRowsFinite(finalPrediction); err != nil {
		return zero, fmt.Errorf("final prediction finite: %w", err)
	}
	if err := equal(fx.Config, originalConfig); err != nil {
		return zero, fmt.Errorf("caller config changed: %w", err)
	}
	if err := equal(fx.Parameters, originalParameters); err != nil {
		return zero, fmt.Errorf("caller parameters changed: %w", err)
	}
	if err := equal(fx.Input, originalInput); err != nil {
		return zero, fmt.Errorf("caller input changed: %w", err)
	}
	if err := equal(fx.Upstream, originalUpstream); err != nil {
		return zero, fmt.Errorf("caller upstream changed: %w", err)
	}
	if err := equal(fx.Target, originalTarget); err != nil {
		return zero, fmt.Errorf("caller target changed: %w", err)
	}
	return matrixRecord{Key: key, Operations: len(auditOperations), PredictionSHA256: hash(finalPrediction), FirstGradientSHA256: hash(publicGradient), FinalSnapshotSHA256: hash(normalized(finalSnapshot)), ParametersChanged: true, FirstUpdateMeanNorm: firstUpdateMeanNorm, FirstUpdateClipped: firstUpdateClipped}, nil
}

func auditTrainerOperation(ctx context.Context, trainer *learning.Trainer, operation string, fx fixture) (learning.StepResult, [][]float64, []float64, [][]float64, error) {
	input := auditCloneRows(fx.Input)
	target := append([]float64(nil), fx.Target...)
	upstream := auditCloneRows(fx.Upstream)
	var (
		result learning.StepResult
		err    error
	)
	switch operation {
	case "step":
		result, err = trainer.Step(ctx, input, target)
	case "from":
		result, err = trainer.StepFrom(ctx, input, upstream)
	default:
		err = fmt.Errorf("unknown operation %q", operation)
	}
	return result, input, target, upstream, err
}

func runControls(ctx context.Context) ([]controlRecord, int, error) {
	controls := make([]controlRecord, 0, 22)
	for _, core := range []string{"continuous", "lif"} {
		key := caseKey{Core: core, Filled: 3, Delay: 2, Window: 0, Segment: 1}
		base, err := auditFixture(key)
		if err != nil {
			return nil, 0, err
		}
		baseNetwork, err := learning.NewNetwork(base.Config)
		if err != nil {
			return nil, 0, fmt.Errorf("%s base network: %w", core, err)
		}
		baseRows, err := baseNetwork.PredictAll(ctx, auditCloneParameters(base.Parameters), auditCloneRows(base.Input))
		if err != nil {
			return nil, 0, fmt.Errorf("%s base prediction: %w", core, err)
		}
		baseGradient, err := baseNetwork.LossGradientFrom(ctx, auditCloneParameters(base.Parameters), auditCloneRows(base.Input), auditCloneRows(base.Upstream), 0)
		if err != nil {
			return nil, 0, fmt.Errorf("%s base gradient: %w", core, err)
		}
		variants := []struct {
			name   string
			mutate func(*learning.Config)
		}{
			{name: "plain", mutate: func(c *learning.Config) { c.Chemistry = nil }},
			{name: "expression", mutate: func(c *learning.Config) { c.Chemistry.Part.Expression = nil }},
			{name: "transport", mutate: func(c *learning.Config) { c.Chemistry.Part.Config.Chemistry.Transport = nil }},
		}
		for index := 0; index < 5; index++ {
			i := index
			variants = append(variants, struct {
				name   string
				mutate func(*learning.Config)
			}{name: fmt.Sprintf("source-%d-zero-release", i), mutate: func(c *learning.Config) {
				c.Chemistry.Part.Config.Sources[i] = modulationZeroSource(i)
				c.Chemistry.Part.SourceStates[i] = learning.ChemicalSourceState{}
			}})
		}
		variants = append(variants,
			struct {
				name   string
				mutate func(*learning.Config)
			}{name: "energy", mutate: func(c *learning.Config) { c.Chemistry.Part.Resources["energy"] = .1 }},
			struct {
				name   string
				mutate func(*learning.Config)
			}{name: "feedback-late", mutate: func(c *learning.Config) { c.Chemistry.Part.PendingFeedback[0].AvailableAt.Value = 99 }},
			struct {
				name   string
				mutate func(*learning.Config)
			}{name: "controller-history-empty", mutate: func(c *learning.Config) {
				state := c.Chemistry.Part.SourceStates[0].Controller
				state.Filled = 0
				for row := range state.Window {
					for column := range state.Window[row] {
						state.Window[row][column] = 0
					}
				}
			}},
		)
		for _, variant := range variants {
			config, err := auditCloneConfig(base.Config)
			if err != nil {
				return nil, 0, err
			}
			variant.mutate(&config)
			network, err := learning.NewNetwork(config)
			if err != nil {
				return nil, 0, fmt.Errorf("%s %s network: %w", core, variant.name, err)
			}
			rows, err := network.PredictAll(ctx, auditCloneParameters(base.Parameters), auditCloneRows(base.Input))
			if err != nil {
				return nil, 0, fmt.Errorf("%s %s prediction: %w", core, variant.name, err)
			}
			gradient, err := network.LossGradientFrom(ctx, auditCloneParameters(base.Parameters), auditCloneRows(base.Input), auditCloneRows(base.Upstream), 0)
			if err != nil {
				return nil, 0, fmt.Errorf("%s %s gradient: %w", core, variant.name, err)
			}
			if err := auditRowsFinite(rows); err != nil {
				return nil, 0, fmt.Errorf("%s %s output finite: %w", core, variant.name, err)
			}
			if err := auditGradientFinite(gradient); err != nil {
				return nil, 0, fmt.Errorf("%s %s gradient finite: %w", core, variant.name, err)
			}
			outputsDiffer, gradientsDiffer := equal(baseRows, rows) != nil, equal(baseGradient, gradient) != nil
			if !outputsDiffer && !gradientsDiffer {
				return nil, 0, fmt.Errorf("%s control %s changed neither outputs nor gradients", core, variant.name)
			}
			controls = append(controls, controlRecord{Core: core, Name: variant.name, OutputsDiffer: outputsDiffer, GradientsDiffer: gradientsDiffer})
		}
	}
	ownership, err := auditOwnership(ctx)
	if err != nil {
		return nil, 0, err
	}
	return controls, ownership, nil
}

func modulationZeroSource(channel int) modulation.SourceSpec {
	return modulation.SourceSpec{Kind: modulation.SourceExternalTimeline, Channel: channel, Timeline: &modulation.ExternalTimeline{ChannelCount: channel + 1}}
}

func auditOwnership(ctx context.Context) (int, error) {
	for _, core := range []string{"continuous", "lif"} {
		key := caseKey{Core: core, Filled: 3, Delay: 2, Window: 0, Segment: 1}
		fx, err := auditFixture(key)
		if err != nil {
			return 0, err
		}
		callerConfig, err := auditCloneConfig(fx.Config)
		if err != nil {
			return 0, err
		}
		callerParameters := auditCloneParameters(fx.Parameters)
		network, err := learning.NewNetwork(callerConfig)
		if err != nil {
			return 0, fmt.Errorf("%s ownership network: %w", core, err)
		}
		trainer, err := learning.NewTrainer(callerConfig, callerParameters, auditOptions(key, false))
		if err != nil {
			return 0, fmt.Errorf("%s ownership trainer: %w", core, err)
		}
		beforeNetwork := network.Config()
		beforeTrainer := trainer.Snapshot()
		callerConfig.Chemistry.Part.Config.Sources[0].Controller.Parameters[0] += .11
		callerConfig.Chemistry.Part.Config.Chemistry.Transport.Fraction[0][1] = .9
		callerConfig.Chemistry.Part.Config.Sources[4].Replay.Trace[7][4] += .11
		callerConfig.Chemistry.Part.Resources["energy"] = 4
		callerConfig.Chemistry.Part.Config.Sources[0].Controller.Inputs.SummaryWindow = 1
		callerParameters.Core.Weights[0] += .13
		if err := equal(beforeNetwork, network.Config()); err != nil {
			_ = trainer.Close()
			return 0, fmt.Errorf("%s network config aliases caller: %w", core, err)
		}
		if err := equal(beforeTrainer, trainer.Snapshot()); err != nil {
			_ = trainer.Close()
			return 0, fmt.Errorf("%s trainer state aliases caller: %w", core, err)
		}
		if err := trainer.Close(); err != nil {
			return 0, fmt.Errorf("%s ownership close: %w", core, err)
		}
		_ = ctx
	}
	return 2, nil
}

func runReferences(ctx context.Context) ([]referenceRecord, error) {
	references := make([]referenceRecord, 0, 54)
	const epsilon = .002
	for _, filled := range []int{0, 1, 3} {
		key := caseKey{Core: "continuous", Filled: filled, Delay: 2, Window: 0, Segment: 1}
		fx, err := auditFixture(key)
		if err != nil {
			return nil, err
		}
		network, err := learning.NewNetwork(fx.Config)
		if err != nil {
			return nil, err
		}
		parameters := auditCloneParameters(fx.Parameters)
		public, err := network.LossGradientFrom(ctx, parameters, auditCloneRows(fx.Input), auditCloneRows(fx.Upstream), 0)
		if err != nil {
			return nil, fmt.Errorf("filled %d public gradient: %w", filled, err)
		}
		if err := auditGradientFinite(public); err != nil {
			return nil, err
		}
		flat := auditFlatGradient(public)
		coordinates := auditParameterCoordinates(parameters)
		if len(coordinates) != len(flat) || len(flat) != 10 {
			return nil, fmt.Errorf("filled %d parameter shape %d/%d, want 10", filled, len(coordinates), len(flat))
		}
		for index, coordinate := range coordinates {
			plus := auditCloneParameters(parameters)
			minus := auditCloneParameters(parameters)
			coordinate.set(&plus, epsilon)
			coordinate.set(&minus, -epsilon)
			plusObjective, err := auditObjective(ctx, network, plus, fx.Input, fx.Upstream)
			if err != nil {
				return nil, fmt.Errorf("filled %d %s plus: %w", filled, coordinate.name, err)
			}
			minusObjective, err := auditObjective(ctx, network, minus, fx.Input, fx.Upstream)
			if err != nil {
				return nil, fmt.Errorf("filled %d %s minus: %w", filled, coordinate.name, err)
			}
			reference := (plusObjective - minusObjective) / (2 * epsilon)
			tolerance := .002 + .002*math.Abs(reference)
			absolute := math.Abs(flat[index] - reference)
			if !auditFiniteFloat(reference) || absolute > tolerance {
				return nil, fmt.Errorf("filled %d %s gradient=%g reference=%g error=%g tolerance=%g", filled, coordinate.name, flat[index], reference, absolute, tolerance)
			}
			references = append(references, referenceRecord{Filled: filled, Coordinate: coordinate.name, Gradient: flat[index], Reference: reference, AbsoluteError: absolute, Tolerance: tolerance})
		}
		for row := range fx.Input {
			plus := auditCloneRows(fx.Input)
			minus := auditCloneRows(fx.Input)
			plus[row][0] += epsilon
			minus[row][0] -= epsilon
			plusObjective, err := auditObjective(ctx, network, parameters, plus, fx.Upstream)
			if err != nil {
				return nil, fmt.Errorf("filled %d input[%d] plus: %w", filled, row, err)
			}
			minusObjective, err := auditObjective(ctx, network, parameters, minus, fx.Upstream)
			if err != nil {
				return nil, fmt.Errorf("filled %d input[%d] minus: %w", filled, row, err)
			}
			reference := (plusObjective - minusObjective) / (2 * epsilon)
			tolerance := .002 + .002*math.Abs(reference)
			if !auditFiniteFloat(reference) || row >= len(public.Inputs) || len(public.Inputs[row]) != 1 {
				return nil, fmt.Errorf("filled %d input[%d] invalid reference/gradient", filled, row)
			}
			absolute := math.Abs(public.Inputs[row][0] - reference)
			if absolute > tolerance {
				return nil, fmt.Errorf("filled %d input[%d] gradient=%g reference=%g error=%g tolerance=%g", filled, row, public.Inputs[row][0], reference, absolute, tolerance)
			}
			references = append(references, referenceRecord{Filled: filled, Coordinate: fmt.Sprintf("input[%d]", row), Gradient: public.Inputs[row][0], Reference: reference, AbsoluteError: absolute, Tolerance: tolerance})
		}
	}
	return references, nil
}

type auditParameterCoordinate struct {
	name string
	set  func(*learning.Parameters, float64)
}

func auditParameterCoordinates(p learning.Parameters) []auditParameterCoordinate {
	coordinates := make([]auditParameterCoordinate, 0, 10)
	for index := range p.Core.Weights {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("weights[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Core.Weights[i] += delta }})
	}
	for index := range p.Core.Bias {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("bias[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Core.Bias[i] += delta }})
	}
	for index := range p.Core.LogTau {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("log_tau[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Core.LogTau[i] += delta }})
	}
	for index := range p.Encoder {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("encoder[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Encoder[i] += delta }})
	}
	for index := range p.Readout {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("readout[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Readout[i] += delta }})
	}
	return coordinates
}

func auditObjective(ctx context.Context, network *learning.Network, p learning.Parameters, input, upstream [][]float64) (float64, error) {
	rows, err := network.PredictAll(ctx, auditCloneParameters(p), auditCloneRows(input))
	if err != nil {
		return 0, err
	}
	if len(rows) != len(upstream) {
		return 0, fmt.Errorf("prediction rows=%d upstream rows=%d", len(rows), len(upstream))
	}
	var objective float64
	for row := range rows {
		if len(rows[row]) != len(upstream[row]) {
			return 0, fmt.Errorf("objective row %d width mismatch", row)
		}
		for column := range rows[row] {
			objective += rows[row][column] * upstream[row][column]
		}
	}
	if !auditFiniteFloat(objective) {
		return 0, fmt.Errorf("objective is not finite")
	}
	return objective, nil
}

func writeResumeCases(ctx context.Context, newDir string) ([]string, error) {
	if err := auditContextError(ctx); err != nil {
		return nil, err
	}
	if newDir == "" {
		return nil, fmt.Errorf("empty resume directory")
	}
	if err := os.MkdirAll(newDir, 0o755); err != nil {
		return nil, err
	}
	paths := make([]string, 0, 16)
	for _, core := range []string{"continuous", "lif"} {
		for _, filled := range []int{1, 3} {
			for _, window := range []int{0, 3} {
				for _, segment := range []int{1, 5} {
					key := caseKey{Core: core, Filled: filled, Delay: 5, Window: window, Segment: segment}
					fx, err := auditFixture(key)
					if err != nil {
						return nil, err
					}
					full, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, false))
					if err != nil {
						return nil, fmt.Errorf("resume full %+v: %w", key, err)
					}
					recompute, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, true))
					if err != nil {
						_ = full.Close()
						return nil, fmt.Errorf("resume recompute %+v: %w", key, err)
					}
					firstFull, err := full.StepFrom(ctx, auditCloneRows(fx.Input), auditCloneRows(fx.Upstream))
					if err != nil {
						_ = full.Close()
						_ = recompute.Close()
						return nil, fmt.Errorf("resume full first %+v: %w", key, err)
					}
					firstRecompute, err := recompute.StepFrom(ctx, auditCloneRows(fx.Input), auditCloneRows(fx.Upstream))
					if err != nil {
						_ = full.Close()
						_ = recompute.Close()
						return nil, fmt.Errorf("resume recompute first %+v: %w", key, err)
					}
					if firstFull.Accumulated != 1 || firstRecompute.Accumulated != 1 {
						_ = full.Close()
						_ = recompute.Close()
						return nil, fmt.Errorf("resume first accumulation %+v full=%d recompute=%d", key, firstFull.Accumulated, firstRecompute.Accumulated)
					}
					if err := equal(normalized(full.Snapshot()), normalized(recompute.Snapshot())); err != nil {
						_ = full.Close()
						_ = recompute.Close()
						return nil, fmt.Errorf("resume pending snapshot %+v: %w", key, err)
					}
					operations := []string{"step", "from", "step", "from"}
					expected, err := continueTrainer(ctx, full, key, operations)
					if err != nil {
						_ = full.Close()
						_ = recompute.Close()
						return nil, fmt.Errorf("resume expected %+v: %w", key, err)
					}
					path := auditResumePath(newDir, key)
					if err := auditWriteJSON(path, resumeInput{Key: key, Snapshot: recompute.Snapshot(), Operations: operations, Expected: expected}); err != nil {
						_ = full.Close()
						_ = recompute.Close()
						return nil, fmt.Errorf("resume write %+v: %w", key, err)
					}
					if err := full.Close(); err != nil {
						_ = recompute.Close()
						return nil, fmt.Errorf("resume full close %+v: %w", key, err)
					}
					if err := recompute.Close(); err != nil {
						return nil, fmt.Errorf("resume recompute close %+v: %w", key, err)
					}
					paths = append(paths, path)
				}
			}
		}
	}
	return paths, nil
}

func continueTrainer(ctx context.Context, trainer *learning.Trainer, key caseKey, operations []string) ([]trace, error) {
	if trainer == nil {
		return nil, fmt.Errorf("nil trainer")
	}
	fx, err := auditFixture(key)
	if err != nil {
		return nil, err
	}
	traces := make([]trace, 0, len(operations))
	for index, operation := range operations {
		if err := auditContextError(ctx); err != nil {
			return nil, err
		}
		input := auditCloneRows(fx.Input)
		upstream := auditCloneRows(fx.Upstream)
		target := append([]float64(nil), fx.Target...)
		var result learning.StepResult
		switch operation {
		case "step":
			result, err = trainer.Step(ctx, input, target)
		case "from":
			result, err = trainer.StepFrom(ctx, input, upstream)
		default:
			return nil, fmt.Errorf("operation %d %q is unknown", index, operation)
		}
		if err != nil {
			return nil, fmt.Errorf("operation %d %s: %w", index, operation, err)
		}
		if err := auditResultFinite(result); err != nil {
			return nil, fmt.Errorf("operation %d result: %w", index, err)
		}
		predictions, err := trainer.PredictAll(ctx, auditCloneRows(fx.Input))
		if err != nil {
			return nil, fmt.Errorf("operation %d predictions: %w", index, err)
		}
		if err := auditRowsFinite(predictions); err != nil {
			return nil, fmt.Errorf("operation %d predictions: %w", index, err)
		}
		traces = append(traces, trace{Result: result, Snapshot: normalized(trainer.Snapshot()), Predictions: predictions})
	}
	return traces, nil
}

func auditFlatGradient(g learning.Gradient) []float64 {
	values := make([]float64, 0)
	values = append(values, g.Core.Weights...)
	values = append(values, g.Core.Bias...)
	values = append(values, g.Core.LogTau...)
	values = append(values, g.ThetaRaw...)
	values = append(values, g.Encoder...)
	values = append(values, g.Readout...)
	return values
}

func auditAnyNonzero(values []float64) bool {
	for _, value := range values {
		if value != 0 {
			return true
		}
	}
	return false
}

func auditGradientFinite(g learning.Gradient) error {
	for name, values := range map[string][]float64{"weights": g.Core.Weights, "bias": g.Core.Bias, "log_tau": g.Core.LogTau, "initial": g.Core.Initial, "theta_raw": g.ThetaRaw, "encoder": g.Encoder, "readout": g.Readout} {
		for index, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("%s[%d]=%g", name, index, value)
			}
		}
	}
	for row, values := range g.Inputs {
		for column, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("inputs[%d][%d]=%g", row, column, value)
			}
		}
	}
	for row, values := range g.Core.Inputs {
		for column, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("core inputs[%d][%d]=%g", row, column, value)
			}
		}
	}
	return nil
}

func auditRowsFinite(rows [][]float64) error {
	for row, values := range rows {
		for column, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("row[%d][%d]=%g", row, column, value)
			}
		}
	}
	return nil
}

func auditResultFinite(result learning.StepResult) error {
	for name, value := range map[string]float64{"loss": result.Loss, "gradient_norm": result.GradientNorm, "update_norm": result.UpdateNorm, "learning_rate": result.LearningRate} {
		if !auditFiniteFloat(value) {
			return fmt.Errorf("%s=%g", name, value)
		}
	}
	return nil
}
