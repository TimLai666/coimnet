package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"

	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/learning"
	"github.com/TimLai666/coimnet/modulation"
	"github.com/TimLai666/coimnet/signal"
)

// auditFixture is deliberately built through the same public declarations as
// the existing chemical recomputation tests.  Five sources are required here
// because ChemistryConfig requires one source for every channel, in order.
func auditFixture(key caseKey) (fixture, error) {
	if key.Core != "continuous" && key.Core != "lif" {
		return fixture{}, fmt.Errorf("unknown audit core %q", key.Core)
	}
	if key.Filled < 0 || key.Filled > 4 {
		return fixture{}, fmt.Errorf("invalid controller fill %d", key.Filled)
	}
	if key.Delay != 2 && key.Delay != 5 {
		return fixture{}, fmt.Errorf("invalid audit delay %d", key.Delay)
	}
	if key.Window < 0 || key.Window > 5 {
		return fixture{}, fmt.Errorf("invalid audit truncation window %d", key.Window)
	}
	if key.Segment < 1 {
		return fixture{}, fmt.Errorf("invalid audit segment %d", key.Segment)
	}

	var config learning.Config
	var parameters learning.Parameters
	if key.Core == "continuous" {
		config = learning.Config{
			Dynamics: dynamics.Config{
				Nodes: 2, Sources: []int{0, 1}, Targets: []int{0, 1},
				Delays: []int{key.Delay, key.Delay}, DT: .7, Activation: "tanh",
			},
			InputSize: 1, OutputSize: 1, ReadoutNodes: []int{0, 1},
			InputNodes: []int{0, 1}, ReadoutEveryStep: true,
		}
		parameters = learning.Parameters{
			Core: dynamics.Parameters{
				Weights: []float64{.25, -.18}, Bias: []float64{.05, -.03}, LogTau: []float64{.1, -.05},
			},
			Encoder: []float64{.45, -.35}, Readout: []float64{.6, -.4},
		}
	} else {
		lif := dynamics.LIFConfig{
			Nodes: 2, Sources: []int{0, 1}, Targets: []int{1, 0}, Delays: []int{key.Delay, key.Delay},
			DT: .5, TauSyn: .8, ThetaMin: .1, ThetaMax: 1.7, VReset: -.5, RefractorySteps: 2,
			Adaptation:  dynamics.LIFAdaptation{Enabled: true, TauAdapt: 1.1, Beta: .18},
			Homeostasis: &dynamics.LIFHomeostasis{Enabled: true, TauRate: 1.7, TargetRate: .2, Eta: .2, HMax: .4},
			Surrogate:   dynamics.LIFSurrogate{Kind: "fast_sigmoid", Scale: 1.7},
		}
		config = learning.Config{
			LIF: &lif, InputSize: 1, OutputSize: 1, ReadoutNodes: []int{0, 1},
			InputNodes: []int{0, 1}, ReadoutEveryStep: true,
		}
		parameters = learning.Parameters{
			Core: dynamics.Parameters{
				Weights: []float64{.22, -.18}, Bias: []float64{.1, .08}, LogTau: []float64{-.15, -.1},
			},
			ThetaRaw: []float64{-.2, -.1}, Encoder: []float64{1.2, .95}, Readout: []float64{.7, -.45},
		}
	}
	config.Chemistry = auditChemicalEpisode(key.Core, key.Filled)
	input := make([][]float64, 8)
	upstream := make([][]float64, 8)
	for step := range input {
		if key.Core == "continuous" {
			input[step] = []float64{.35 + .06*float64(step)}
			upstream[step] = []float64{10 * (.08 - .006*float64(step))}
		} else {
			input[step] = []float64{1.35 + .05*float64(step%3)}
			upstream[step] = []float64{10 * (.04 - .003*float64(step))}
		}
	}
	if key.Core == "continuous" {
		return fixture{Config: config, Parameters: parameters, Input: input, Target: []float64{.24}, Upstream: upstream}, nil
	}
	return fixture{Config: config, Parameters: parameters, Input: input, Target: []float64{.18}, Upstream: upstream}, nil
}

func auditChemicalEpisode(core string, filled int) *learning.ChemicalEpisode {
	controller := &modulation.Controller{
		Inputs: modulation.ControllerInputs{SummaryWindow: 4, UseFeedback: true, Resources: []string{"energy"}},
		Nodes:  2, Hidden: 1, Channel: 0,
		Parameters: []float64{.35, .1, .4, .2, .05, .7, -.1},
	}
	trace := make([][]float64, 16)
	for step := range trace {
		trace[step] = make([]float64, 5)
		// Every row is distinct while only the replay channel is nonzero;
		// rows 7..14 are the absolute source-clock rows consumed below.
		trace[step][4] = .01 + .01*float64(step)
	}
	chemistry := modulation.ChemistryConfig{
		Chemistry: modulation.Chemistry{
			Regions: 2, Channels: 5, DT: 1, Tau: []float64{2, 2.5, 3, 3.5, 4},
			Transport: &modulation.Transport{Fraction: [][]float64{{0, .2}, {.3, 0}}},
		},
		Sources: []modulation.SourceSpec{
			{Kind: modulation.SourceController, Channel: 0, Controller: controller},
			{Kind: modulation.SourceExternalTimeline, Channel: 1, Timeline: &modulation.ExternalTimeline{
				ChannelCount: 2, Entries: []modulation.TimelineEntry{{Step: 8, Channel: 1, Rate: .75}, {Step: 11, Channel: 1, Rate: .35}},
			}},
			{Kind: modulation.SourceNeuralActivity, Channel: 2, Neural: &modulation.NeuralActivity{
				Nodes: []int{0, 1}, SetName: "both", Gain: 1.2, Channel: 2,
			}},
			{Kind: modulation.SourceInternalResource, Channel: 3, Resource: &modulation.InternalResource{
				Resource: "energy", Coefficient: .6, Threshold: .2, Channel: 3,
			}},
			{Kind: modulation.SourceReplay, Channel: 4, Replay: &modulation.Replay{Trace: trace}},
		},
		Receptors: modulation.Receptors{Records: []modulation.Receptor{
			{Cells: []int{0}, Signal: "channel-0", Channel: 0, Status: modulation.StatusHypothesized,
				Kd: .45, N: 1.2, Evidence: "partial-source-recompute-fixture", MeasurementKind: "declared", MappingVersion: "partial-source-recompute/v1",
				Location: auditLocation(1, "region-1")},
			{Cells: []int{1}, Signal: "channel-1", Channel: 1, Status: modulation.StatusHypothesized,
				Kd: .6, N: 1.1, Evidence: "partial-source-recompute-fixture", MeasurementKind: "declared", MappingVersion: "partial-source-recompute/v1",
				Location: auditLocation(0, "region-0")},
			{Cells: []int{0, 1}, Signal: "channel-2", Channel: 2, Status: modulation.StatusHypothesized,
				Kd: .7, N: 1.4, Evidence: "partial-source-recompute-fixture", MeasurementKind: "declared", MappingVersion: "partial-source-recompute/v1",
				Location: auditLocation(1, "region-1")},
			{Cells: []int{1}, Signal: "channel-3", Channel: 3, Status: modulation.StatusHypothesized,
				Kd: .8, N: 1.2, Evidence: "partial-source-recompute-fixture", MeasurementKind: "declared", MappingVersion: "partial-source-recompute/v1",
				Location: auditLocation(0, "region-0")},
			{Cells: []int{0, 1}, Signal: "channel-4", Channel: 4, Status: modulation.StatusHypothesized,
				Kd: 1, N: 1.2, Evidence: "partial-source-recompute-fixture", MeasurementKind: "declared", MappingVersion: "partial-source-recompute/v1",
				Location: auditLocation(0, "region-0")},
		}},
		Regions: modulation.RegionAssignment{NodeRegion: []int{0, 1}},
	}
	// Effects that reach the same cell must declare the same sensitivity
	// coefficients. The inherited receptor records overlap the new channel-3/4
	// records, so all sensitivity records use the mandated .2/.02 pair.
	if core == "lif" {
		chemistry.Effects = []modulation.Effect{
			{Kind: modulation.EffectThreshold, Receptor: 0, ThetaScale: .35, ThetaAbsMax: .8},
			{Kind: modulation.EffectSensitivity, Receptor: 1, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 2, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 3, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 4, GammaScale: .2, BetaScale: .02},
		}
	} else {
		chemistry.Effects = []modulation.Effect{
			{Kind: modulation.EffectSensitivity, Receptor: 0, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 1, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 2, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 3, GammaScale: .2, BetaScale: .02},
			{Kind: modulation.EffectSensitivity, Receptor: 4, GammaScale: .2, BetaScale: .02},
		}
	}
	window := [][]float64{{0, 0}, {0, 0}, {0, 0}, {0, 0}}
	values := [][]float64{{.08, -.02}, {.12, .03}, {.18, .06}, {.22, .1}}
	start := len(window) - filled
	for row := start; row < len(window); row++ {
		window[row] = append([]float64(nil), values[row]...)
	}
	initialActivity := []float64{.2, -.1}
	if core == "lif" {
		initialActivity = []float64{.15, -.05}
	}
	return &learning.ChemicalEpisode{
		Part: learning.ChemicalPart{
			Config:    chemistry,
			State:     modulation.ChemistryState{Concentration: [][]float64{{.21, .13, .07, .04, .09}, {.16, .24, .11, .08, .05}}, Steps: 3},
			Resources: map[string]float64{"energy": .8},
			PendingFeedback: []signal.FeedbackSpec{{
				SchemaVersion: signal.CurrentSchemaVersion(), ExperienceID: "partial-source-recompute", ActionID: "action",
				ProducedAt: signal.Timestamp{Value: 8, Unit: signal.TimeUnitModelStep}, AvailableAt: signal.Timestamp{Value: 9, Unit: signal.TimeUnitModelStep},
				Source: "fixture", Score: .35, ModelVersion: signal.CurrentSchemaVersion(),
			}},
			SourceStates: []learning.ChemicalSourceState{{Controller: &modulation.ControllerState{Window: window, Filled: filled}}, {}, {}, {}, {}},
			Expression:   &learning.ExpressionGain{Nodes: []int{0}, Receptor: 0, Scale: .7, Min: .5, Max: 2},
		},
		SourceStep: 7, InitialActivity: initialActivity,
	}
}

func auditLocation(region int, name string) *modulation.ReceptorLocation {
	return &modulation.ReceptorLocation{Region: region, Compartment: "postsynaptic", AnatomicalLocation: name,
		Evidence: "partial-source-recompute-fixture", MeasurementKind: "declared", MappingVersion: "partial-source-recompute-location/v1"}
}

func auditOptions(key caseKey, recompute bool) learning.Options {
	o := learning.DefaultOptions()
	o.LearningRate = .013
	o.Beta1 = .83
	o.Beta2 = .991
	o.Epsilon = 1e-8
	o.WeightDecay = .001
	o.ClipNorm = .7
	o.Truncation = key.Window
	o.AccumulateSteps = 2
	o.Trainable = learning.Trainable{Encoder: true, Weights: true, Bias: true, Tau: true, Readout: true, Theta: key.Core == "lif"}
	o.Schedule = &learning.Schedule{Kind: learning.ScheduleStep, WarmupUpdates: 2, StepEvery: 2, StepFactor: .6}
	if recompute {
		o.Recompute = &learning.Recompute{SegmentSteps: key.Segment}
	}
	return o
}

func auditCloneConfig(c learning.Config) (learning.Config, error) {
	b, err := json.Marshal(c)
	if err != nil {
		return learning.Config{}, err
	}
	var out learning.Config
	if err := json.Unmarshal(b, &out); err != nil {
		return learning.Config{}, err
	}
	return out, nil
}

func auditCloneParameters(p learning.Parameters) learning.Parameters {
	return learning.Parameters{Core: dynamics.Parameters{
		Weights: append([]float64(nil), p.Core.Weights...), Bias: append([]float64(nil), p.Core.Bias...), LogTau: append([]float64(nil), p.Core.LogTau...),
	}, ThetaRaw: append([]float64(nil), p.ThetaRaw...), Encoder: append([]float64(nil), p.Encoder...), Readout: append([]float64(nil), p.Readout...)}
}

func auditCloneRows(rows [][]float64) [][]float64 {
	if rows == nil {
		return nil
	}
	out := make([][]float64, len(rows))
	for i, row := range rows {
		out[i] = append([]float64(nil), row...)
	}
	return out
}

func auditFiniteFloat(v float64) bool { return !math.IsNaN(v) && !math.IsInf(v, 0) }

func auditWriteJSON(path string, value any) error {
	b, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	if _, err := os.Stat(path); err == nil {
		return fmt.Errorf("refusing to overwrite existing resume input %s", path)
	} else if !os.IsNotExist(err) {
		return err
	}
	return os.WriteFile(path, append(b, '\n'), 0o644)
}

func auditResumePath(dir string, key caseKey) string {
	name := fmt.Sprintf("resume-%s-filled%d-delay%d-window%d-segment%d.json", key.Core, key.Filled, key.Delay, key.Window, key.Segment)
	return filepath.Join(dir, name)
}

func auditContextError(ctx context.Context) error {
	if ctx == nil {
		return fmt.Errorf("nil context")
	}
	return ctx.Err()
}
