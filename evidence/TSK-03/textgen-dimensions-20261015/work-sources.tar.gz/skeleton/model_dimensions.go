package textgen

// This isolated TDD skeleton retains unchecked arithmetic. It is never applied
// to formal sources and allocates no arrays.
func modelParameterLengths(vocabSize, embed, hidden int) (encoder, readout int, err error) {
	return vocabSize * embed, hidden * vocabSize, nil
}
