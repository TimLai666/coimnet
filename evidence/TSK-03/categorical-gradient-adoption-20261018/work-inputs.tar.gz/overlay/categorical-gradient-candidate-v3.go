// Package categorical provides the internal one-hot classification derivative.
package categorical

import (
	"fmt"
	"math"
)

// Gradient overwrites fresh dst with factor/divisor times the derivative of
// cross-entropy. Logits must be finite and nonempty, target must be in range,
// factor must be finite and nonnegative, and divisor must be finite and >= 1.
// dst must match logits in length and must not alias logits. Invalid arguments
// return an error before changing dst. This isolated candidate is not adopted.
func Gradient(dst, logits []float64, target int, factor, divisor float64) error {
	if len(logits) == 0 {
		return fmt.Errorf("categorical: logits must be non-empty")
	}
	if len(dst) != len(logits) {
		return fmt.Errorf("categorical: dst length %d does not match logits length %d", len(dst), len(logits))
	}
	if target < 0 || target >= len(logits) {
		return fmt.Errorf("categorical: target %d out of range", target)
	}
	if math.IsNaN(factor) || math.IsInf(factor, 0) || factor < 0 {
		return fmt.Errorf("categorical: factor must be finite and non-negative")
	}
	if math.IsNaN(divisor) || math.IsInf(divisor, 0) || divisor < 1 {
		return fmt.Errorf("categorical: divisor must be finite and >= 1")
	}
	for i, logit := range logits {
		if math.IsNaN(logit) || math.IsInf(logit, 0) {
			return fmt.Errorf("categorical: logits[%d] must be finite", i)
		}
	}
	if factor == 0 || len(logits) == 1 {
		for i := range dst {
			dst[i] = 0
		}
		return nil
	}

	maximum := logits[0]
	winner := 0
	for i := 1; i < len(logits); i++ {
		if logits[i] > maximum {
			maximum = logits[i]
			winner = i
		}
	}

	// Represent exp(gap) as mantissa*2^exponent. Squaring exp(gap/2) keeps
	// the exponent available when exp(gap) itself is below the subnormal range.
	// Keep the direct path in the normal range; below this point the
	// half-exponential path avoids losing subnormal precision before scaling.
	const directGap = -700.0
	expRepresentation := func(gap float64) (float64, int, bool) {
		if gap >= directGap {
			value := math.Exp(gap)
			if value == 0 {
				return 0, 0, false
			}
			mantissa, exponent := math.Frexp(value)
			return mantissa, exponent, true
		}
		half := math.Exp(gap / 2)
		if half == 0 {
			return 0, 0, false
		}
		halfMantissa, halfExponent := math.Frexp(half)
		squareMantissa, squareExponent := math.Frexp(halfMantissa * halfMantissa)
		return squareMantissa, 2*halfExponent + squareExponent, true
	}

	// Use the largest non-winner gap as a common aggregate scale. Relative
	// terms are ordinary-sized, while the absolute scale retains the tail
	// exponent for the final factor/divisor combination.
	tailMaximum := math.Inf(-1)
	for i, logit := range logits {
		if i != winner && logit > tailMaximum {
			tailMaximum = logit
		}
	}
	tailScaleMantissa, tailScaleExponent, tailScaleOK := expRepresentation(tailMaximum - maximum)
	if !tailScaleOK {
		tailScaleMantissa, tailScaleExponent = 0, 0
	}
	tailSum, tailCompensation := 0.0, 0.0
	nonTargetTailSum, nonTargetTailCompensation := 0.0, 0.0
	for i, logit := range logits {
		if i == winner {
			continue
		}
		relativeGap := logit - tailMaximum
		term := 0.0
		if relativeGap >= directGap {
			term = math.Exp(relativeGap)
		}
		adjusted := term - tailCompensation
		next := tailSum + adjusted
		tailCompensation = (next - tailSum) - adjusted
		tailSum = next
		if i != target {
			adjusted = term - nonTargetTailCompensation
			next = nonTargetTailSum + adjusted
			nonTargetTailCompensation = (next - nonTargetTailSum) - adjusted
			nonTargetTailSum = next
		}
	}
	if math.IsNaN(tailSum) || math.IsInf(tailSum, 0) || math.IsNaN(nonTargetTailSum) || math.IsInf(nonTargetTailSum, 0) {
		return fmt.Errorf("categorical: non-finite tail aggregate")
	}

	// Convert an aggregate to an ordinary float only for the normalizer. The
	// gradient path below keeps the same representation through factor/divisor.
	toFloat := func(relative, scaleMantissa float64, scaleExponent int) (float64, error) {
		if relative == 0 || scaleMantissa == 0 {
			return 0, nil
		}
		relativeMantissa, relativeExponent := math.Frexp(relative)
		value := math.Ldexp(relativeMantissa*scaleMantissa, relativeExponent+scaleExponent)
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return 0, fmt.Errorf("categorical: non-finite tail mass")
		}
		return value, nil
	}
	tailMass, err := toFloat(tailSum, tailScaleMantissa, tailScaleExponent)
	if err != nil {
		return err
	}
	normalizer := 1 + tailMass
	if math.IsNaN(normalizer) || math.IsInf(normalizer, 0) || normalizer <= 0 {
		return fmt.Errorf("categorical: non-finite normalizer")
	}
	inverseNormalizer := 1 / normalizer
	if math.IsNaN(inverseNormalizer) || math.IsInf(inverseNormalizer, 0) || inverseNormalizer <= 0 {
		return fmt.Errorf("categorical: non-finite inverse normalizer")
	}

	inverseMantissa, inverseExponent := math.Frexp(inverseNormalizer)
	factorMantissa, factorExponent := math.Frexp(factor)
	divisorMantissa, divisorExponent := math.Frexp(divisor)
	applyScaled := func(relative, scaleMantissa float64, scaleExponent int) (float64, error) {
		if relative == 0 || scaleMantissa == 0 {
			return 0, nil
		}
		relativeMantissa, relativeExponent := math.Frexp(relative)
		mantissa := relativeMantissa * scaleMantissa
		mantissa *= inverseMantissa
		mantissa *= factorMantissa
		mantissa /= divisorMantissa
		result := math.Ldexp(mantissa, relativeExponent+scaleExponent+inverseExponent+factorExponent-divisorExponent)
		if math.IsNaN(result) || math.IsInf(result, 0) {
			return 0, fmt.Errorf("categorical: final gradient is non-finite")
		}
		return result, nil
	}
	applyValue := func(value float64) (float64, error) {
		return applyScaled(value, 1, 0)
	}

	for i, logit := range logits {
		if i == target && target != winner {
			continue
		}
		var value float64
		if i == winner {
			if target == winner {
				value, err = applyScaled(tailSum, tailScaleMantissa, tailScaleExponent)
			} else {
				value, err = applyValue(1)
			}
		} else {
			classMantissa, classExponent, classOK := expRepresentation(logit - maximum)
			if classOK {
				value, err = applyScaled(1, classMantissa, classExponent)
			}
		}
		if err != nil {
			return err
		}
		if i == target {
			dst[i] = -value
		} else {
			dst[i] = value
		}
	}

	if target != winner {
		nonTargetTailMass, err := toFloat(nonTargetTailSum, tailScaleMantissa, tailScaleExponent)
		if err != nil {
			return err
		}
		value, err := applyValue(1 + nonTargetTailMass)
		if err != nil {
			return err
		}
		dst[target] = -value
	}

	return nil
}
