// Package categorical provides the internal one-hot classification derivative.
package categorical

import (
	"fmt"
	"math"
)

// Gradient overwrites fresh dst with factor/divisor times the derivative of
// cross-entropy. Logits must be finite and nonempty, target must be in range,
// factor must be finite and nonnegative, and divisor must be finite and >= 1.
// dst must match logits in length and must not alias logits. Invalid arguments
// return an error before changing dst. This isolated candidate is not adopted.
func Gradient(dst, logits []float64, target int, factor, divisor float64) error {
	if len(logits) == 0 {
		return fmt.Errorf("categorical: logits must be non-empty")
	}
	if len(dst) != len(logits) {
		return fmt.Errorf("categorical: dst length %d does not match logits length %d", len(dst), len(logits))
	}
	if target < 0 || target >= len(logits) {
		return fmt.Errorf("categorical: target %d out of range", target)
	}
	if math.IsNaN(factor) || math.IsInf(factor, 0) || factor < 0 {
		return fmt.Errorf("categorical: factor must be finite and non-negative")
	}
	if math.IsNaN(divisor) || math.IsInf(divisor, 0) || divisor < 1 {
		return fmt.Errorf("categorical: divisor must be finite and >= 1")
	}
	for i, logit := range logits {
		if math.IsNaN(logit) || math.IsInf(logit, 0) {
			return fmt.Errorf("categorical: logits[%d] must be finite", i)
		}
	}

	// Validate every input before the canonical zero fast path. This also
	// keeps invalid non-finite logits from being hidden by factor == 0.
	if factor == 0 || len(logits) == 1 {
		for i := range dst {
			dst[i] = 0
		}
		return nil
	}

	maximum := logits[0]
	winner := 0
	for i := 1; i < len(logits); i++ {
		if logits[i] > maximum {
			maximum = logits[i]
			winner = i
		}
	}

	// Terms below this gap are accumulated after multiplying by 2^512. That
	// scale keeps exp(-740..-750) and their aggregates alive until factor and
	// divisor have both been applied. The split also avoids naive order-dependent
	// underflow by using separate compensated sums for ordinary and tiny terms.
	const tinyScaleExponent = 512
	const tinyGap = -512 * math.Ln2
	ordinaryTail := 0.0
	ordinaryTailCompensation := 0.0
	scaledTail := 0.0
	scaledTailCompensation := 0.0
	for i, logit := range logits {
		if i == winner {
			continue
		}
		gap := logit - maximum
		if gap < tinyGap {
			half := math.Exp(gap / 2)
			term := math.Ldexp(half, tinyScaleExponent) * half
			y := term - scaledTailCompensation
			next := scaledTail + y
			scaledTailCompensation = (next - scaledTail) - y
			scaledTail = next
		} else {
			term := math.Exp(gap)
			y := term - ordinaryTailCompensation
			next := ordinaryTail + y
			ordinaryTailCompensation = (next - ordinaryTail) - y
			ordinaryTail = next
		}
	}
	if math.IsNaN(ordinaryTail) || math.IsInf(ordinaryTail, 0) || math.IsNaN(scaledTail) || math.IsInf(scaledTail, 0) {
		return fmt.Errorf("categorical: non-finite tail aggregate")
	}
	tinyTail := math.Ldexp(scaledTail, -tinyScaleExponent)
	normalizer := 1 + ordinaryTail + tinyTail
	if math.IsNaN(normalizer) || math.IsInf(normalizer, 0) || normalizer <= 0 {
		return fmt.Errorf("categorical: non-finite normalizer")
	}
	inverseNormalizer := 1 / normalizer
	if math.IsNaN(inverseNormalizer) || math.IsInf(inverseNormalizer, 0) || inverseNormalizer <= 0 {
		return fmt.Errorf("categorical: non-finite inverse normalizer")
	}

	// Work with mantissas and integer exponents so a large factor cannot
	// overflow before a tiny probability is scaled back down. The final
	// Ldexp is the only operation that rounds the requested binary64 result.
	inverseMantissa, inverseExponent := math.Frexp(inverseNormalizer)
	factorMantissa, factorExponent := math.Frexp(factor)
	divisorMantissa, divisorExponent := math.Frexp(divisor)
	applyScale := func(value float64, scaleExponent int) (float64, error) {
		if value == 0 {
			return 0, nil
		}
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return 0, fmt.Errorf("categorical: non-finite gradient numerator")
		}
		valueMantissa, valueExponent := math.Frexp(value)
		mantissa := valueMantissa * inverseMantissa
		mantissa *= factorMantissa
		mantissa /= divisorMantissa
		exponent := valueExponent + inverseExponent + factorExponent - divisorExponent + scaleExponent
		result := math.Ldexp(mantissa, exponent)
		if math.IsNaN(result) || math.IsInf(result, 0) {
			return 0, fmt.Errorf("categorical: final gradient is non-finite")
		}
		return result, nil
	}

	// Keep a private result until every derivative is known to be finite. That
	// gives callers the same no-partial-write behavior for a true overflow.
	result := make([]float64, len(logits))
	for i, logit := range logits {
		var numerator float64
		var scaleExponent int
		switch {
		case i == winner:
			if target == winner {
				// When the winner is the target, its derivative is the
				// negative mass of all other classes. Its aggregate stays
				// scaled through normalisation, factor, and divisor.
				scaledOrdinaryTail := math.Ldexp(ordinaryTail, tinyScaleExponent)
				numerator = scaledOrdinaryTail + scaledTail
				scaleExponent = -tinyScaleExponent
			} else {
				// An unlabelled winner contributes its probability itself.
				numerator = 1
				scaleExponent = 0
			}
		case logit-maximum < tinyGap:
			gap := logit - maximum
			half := math.Exp(gap / 2)
			numerator = math.Ldexp(half, tinyScaleExponent) * half
			scaleExponent = -tinyScaleExponent
		default:
			numerator = math.Exp(logit - maximum)
			scaleExponent = 0
		}
		value, err := applyScale(numerator, scaleExponent)
		if err != nil {
			return err
		}
		if i == target {
			result[i] = -value
		} else {
			result[i] = value
		}
	}

	// A non-winner target uses the complement directly. This avoids the
	// unstable p-1 subtraction while retaining the winner's unit mass.
	if target != winner {
		ordinaryNonTargetTail := 0.0
		ordinaryNonTargetCompensation := 0.0
		scaledNonTargetTail := 0.0
		scaledNonTargetCompensation := 0.0
		for i, logit := range logits {
			if i == winner || i == target {
				continue
			}
			gap := logit - maximum
			if gap < tinyGap {
				half := math.Exp(gap / 2)
				term := math.Ldexp(half, tinyScaleExponent) * half
				y := term - scaledNonTargetCompensation
				next := scaledNonTargetTail + y
				scaledNonTargetCompensation = (next - scaledNonTargetTail) - y
				scaledNonTargetTail = next
			} else {
				term := math.Exp(gap)
				y := term - ordinaryNonTargetCompensation
				next := ordinaryNonTargetTail + y
				ordinaryNonTargetCompensation = (next - ordinaryNonTargetTail) - y
				ordinaryNonTargetTail = next
			}
		}
		if math.IsNaN(ordinaryNonTargetTail) || math.IsInf(ordinaryNonTargetTail, 0) || math.IsNaN(scaledNonTargetTail) || math.IsInf(scaledNonTargetTail, 0) {
			return fmt.Errorf("categorical: non-finite target aggregate")
		}
		numerator := 1 + ordinaryNonTargetTail + math.Ldexp(scaledNonTargetTail, -tinyScaleExponent)
		value, err := applyScale(numerator, 0)
		if err != nil {
			return err
		}
		result[target] = -value
	}

	copy(dst, result)
	return nil
}
