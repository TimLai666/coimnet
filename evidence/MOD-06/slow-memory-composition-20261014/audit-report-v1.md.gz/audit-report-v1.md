# Slow memory composition audit

- Audit baseline: `f69be0f82b27b327add5faae4388e25f409ea44c`.
- Scope: read-only review of the MOD-06 plan, project rules, `ENG.md`, the original manual, ticket 18/22, and the live `learning`/`plasticity` source. No Go command was run and no source or test file was changed.

## Problem

Determine whether `Consolidate` can commit individually finite slow and fast layers whose combined effective weight overflows, causing the following public `Advance` to reject the state. Also check Restore/Advance transaction boundaries and the fixed/free sign units.

## Done

The combined-overflow path is **CONFIRMED at source level**. It is reachable through the public snapshot restore path and does not depend on a model-quality assumption. No execution result is claimed.

## CONFIRMED findings

### P1 — `Consolidate` can commit a state that the next `Advance` cannot consume

**Evidence and trigger**

- `learning/consolidation.go:150-180` checks the candidate slow value and the retained plastic value separately, and checks `BaseL2`, `SlowL2`, and `PlasticL2` separately with `math.Hypot`. It does not check the candidate combined effective weight before the commit at `learning/consolidation.go:171-177`.
- `learning/individual.go:196-241` and `learning/consolidation.go:185-214` accept finite slow values and finite fast values within `PlasticMax`; they do not require the combined effective weight to be finite. Thus a valid restored snapshot can carry large finite layers.
- `plasticity/plasticity.go:490-561` performs the actual combined arithmetic and rejects only after `(base+slow)+plastic` (free) or the corresponding fixed-sign magnitude sum becomes non-finite.
- A concrete legal free-edge state is: `M = math.MaxFloat64`, old `slow = 0.75*M`, old `plastic = 0.5*M`, `PlasticMax = M`, `Rate = 0.25`, `Retain = 0.5`, finite base `0.9`, and `Threshold = 0`. Consolidation produces `slow = 0.875*M` and retained `plastic = 0.25*M`; each stored layer and each reported norm is finite, so the current preflight accepts it. The next effective sum is `0.9 + 0.875*M + 0.25*M`, which exceeds `M` and becomes non-finite. `EffectiveWith` then rejects the next `Advance` before its candidate state is committed (`learning/individual.go:606-618, 718-724`).
- The same overflow shape is possible for fixed signs after the base has been converted to effective signed magnitude. The floor only handles values below `WMin`; it does not prevent a positive magnitude sum from overflowing.

**Impact**

`Consolidate` returns success and permanently advances `SlowState`/budget, but the next normal public operation fails until the state is externally repaired. This violates the intended composability of the three memory layers and leaves a committed individual in a state rejected by its own effective-weight path.

**Related contract evidence**

- Ticket 22, lines 34-43, defines `slow += Rate*plastic`, retained plastic, and effective `base + slow + plastic`, with reports for the three layers.
- `ENG.md:223-226` requires consolidation to validate slow, plastic, and the three-layer norm before submission and to reject an unrepresentable actual norm. The current checks do not cover the combined effective value.
- The existing finite tests read at `learning/consolidation_finite_test.go:26-40,42-68,90-113` cover candidate slow overflow, finite large layer norms, and unrepresentable layer norms; they do not cover the successful commit followed by combined effective overflow. These tests were not run in this audit.

**Recommended correction for the owning implementation work**

Extend the same-lock consolidation preflight to validate the effective combined weights using the exact free/fixed arithmetic used by `EffectiveWith`, including the candidate slow layer and retained plastic layer, before mutating either layer. Keep the existing candidate and per-layer norm checks.

## P0/P2 confirmed findings

No P0 or P2 defect was confirmed from the reviewed sources.

## NEEDS INVESTIGATION

### Potential P2 — fixed-sign `BaseL2` metric space is unspecified

- `learning/network.go:43-49`, `learning/constrained.go:133-159`, and `learning/network.go:182-194` establish that a fixed-sign core weight is stored as raw log magnitude `rho` and converted to effective `sign*exp(rho)` before the effective path.
- `plasticity/plasticity.go:490-499` explicitly expects an already-effective base. Slow and plastic are then additive effective-magnitude increments, so their units are consistent with the fixed-sign composition.
- `learning/consolidation.go:142-145` computes `BaseL2` directly from `i.trainer.parameters.Core.Weights`, which is raw `rho` for fixed-sign edges, while `SlowL2` and `PlasticL2` are computed from effective-space increments.
- Ticket 22 requires the three layer norms but does not explicitly say whether `BaseL2` is a raw-parameter norm or an effective-weight norm. If it is intended to describe the three effective layers, the fixed-sign report is dimensionally inconsistent; if raw parameter-space reporting is intentional, there is no defect. The missing decision is the metric-space definition for `ConsolidationReport.BaseL2`. No fixed-sign report assertion was executed.

The fixed/free **composition** units themselves have no confirmed mismatch: free edges add raw base, slow, and fast; fixed edges convert the base to effective signed magnitude, then add slow and fast in magnitude units and apply the floor.

## Restore / Advance boundary review

- Restore validates schema, lengths, finiteness, and fast bounds, then copies state (`learning/individual.go:196-284`); it does not preflight the combined effective weights. This is the reachability mechanism for the P1 finding.
- Advance keeps stepwise neural, chemical, and fast candidates local and commits only after effective-weight, output-finiteness, and context checks (`learning/individual.go:606-618,621-623`). No partial Advance commit defect was confirmed.
- Consolidate holds the individual lock and validates before its layer mutation, but its validation boundary is incomplete for the combined effective arithmetic, as described in P1.

## Changed

| 檔案 | 變更摘要 |
|---|---|
| `runs/.tmp/slow-memory-composition-20261014/review/report.md` | 新增本次唯讀稽核報告。 |

## Actions

| 動作 | 對象 | 結果 |
|---|---|---|
| 唯讀狀態檢查 | Git working tree | `git status --short` 僅見既有 MOD-06 未追蹤準備檔，無 tracked source diff；未執行任何 Git 寫入。 |
| 建立報告 | 指定 `runs/.tmp/.../review/report.md` | 已建立。 |

## Verified

- 已核對 `evidence/MOD-06/slow-memory-composition-20261014/plan.md`、`AGENTS.md`、`README.md`、`docs/initialization.md`、`docs/handoff/AGENT_START_HERE.zh-TW.md`、`ENG.md`。
- 已核對原始手冊 §10.2、§10.4、§11.6，以及 ticket 18、ticket 22 的記憶組合與 fixed/free sign 契約。
- 已核對 live source：`learning/consolidation.go`、`learning/individual.go`、`learning/network.go`、`learning/constrained.go`、`plasticity/plasticity.go`，來源基準均為 `f69be0f82b27b327add5faae4388e25f409ea44c`。
- 判定依來源與可計算觸發值完成；未執行 Go、race、測試、網路或外部 CLI，因此沒有測試通過聲明。

## Notes

- P1 是 source-level reachable finding；尚未由本輪實際 Go 回歸重現。
- P2 的唯一缺口是 `BaseL2` 在 fixed-sign 下應採 raw `rho` 還是 effective magnitude 的正式定義。
- 本報告未修改 Go、測試、文件、資料、模型、Git 或外部設定。

## Next

- 由 root 依授權補一個 Restore → Consolidate → Advance 的 combined-overflow 回歸，並在修正後重新驗證。
- 先決定 `ConsolidationReport.BaseL2` 的 metric space，再決定是否補 fixed-sign 報告測試。

Skills：無
