# Slow memory composition audit

- Audit baseline: `f69be0f82b27b327add5faae4388e25f409ea44c`.
- Scope: read-only review of the MOD-06 plan, project rules, `ENG.md`, the original manual, ticket 18/22, and the live `learning`/`plasticity` source. No Go command was run and no source or test file was changed.
- The previous report bytes are preserved verbatim in `report-v1.md`; its SHA-256 is `9f99b8a1aab3fd3b390f2b676b0b722e2d3182d1096134aa98012b896f511441`.

## Problem

Determine whether `Consolidate` can commit individually finite slow and fast layers whose combined effective weight overflows, causing the following public `Advance` to reject the state. Also check Restore/Advance transaction boundaries and the fixed/free sign units.

## Done

The corrected combined-overflow path is **CONFIRMED at source level**. It starts from a finite, combined-effective state and becomes non-finite only after a successful `Consolidate`; no execution result is claimed.

## CONFIRMED findings

### P1 — `Consolidate` can commit a state that the next `Advance` cannot consume

**Evidence and trigger**

- `learning/consolidation.go:150-180` checks the candidate slow value and the retained plastic value separately, and checks `BaseL2`, `SlowL2`, and `PlasticL2` separately with `math.Hypot`. It does not check the candidate combined effective weight before the commit at `learning/consolidation.go:171-177`.
- `learning/individual.go:196-241` and `learning/consolidation.go:185-214` accept finite slow values and finite fast values within `PlasticMax`; `plasticity/plasticity.go:147-163,255-280` permits any finite positive `PlasticMax` and checks only the individual fast bound. They do not require the combined effective weight to be finite. Thus a valid restored snapshot can carry large finite layers.
- `plasticity/plasticity.go:490-561` performs the actual combined arithmetic and rejects only after `(base+slow)+plastic` (free) or the corresponding fixed-sign magnitude sum becomes non-finite.
- A concrete legal free-edge state is: base `1e308`, old `slow = -1e308`, old `plastic = 1e308`, `PlasticMax = 1e308`, `Rate = 1`, `Retain = 1`, and `Threshold = 0`, with an enabled layer, valid receptor, unused budget, and no duplicate episode marker. Before consolidation, the exact source expression `((base + slow) + plastic)` is `((1e308 + -1e308) + 1e308) = 1e308`, which is finite. Consolidation's candidate slow is `0` and retained plastic is `1e308`; the base, candidate slow norm, and retained plastic norm are all finite, so the current preflight accepts and commits them. Afterward the same expression is `((1e308 + 0) + 1e308) = +Inf`, and `EffectiveWith` rejects the next `Advance` before its candidate state is committed (`learning/individual.go:606-618, 718-724`).
- For a fixed-sign edge, use raw base `log(1e308)` with the corresponding effective base `+1e308`; the same slow/plastic values, `Rate`, and `Retain` produce the same pre/post result after `coreParameters` converts raw log magnitude to effective magnitude. The floor only handles values below `WMin`; it does not prevent a positive magnitude sum from overflowing.
- The earlier `0.75*M` plus `0.5*M` example is intentionally retained only in `report-v1.md`: it was already non-finite before `Consolidate` and therefore showed Restore accepting an already unusable state, not a valid state broken by consolidation.

**Impact**

`Consolidate` returns success and permanently advances `SlowState`/budget, although the pre-consolidation effective arithmetic is finite; the next normal public operation fails until the state is externally repaired. This violates the intended composability of the three memory layers and leaves a committed individual in a state rejected by its own effective-weight path.

**Related contract evidence**

- Ticket 22, lines 34-43, defines `slow += Rate*plastic`, retained plastic, and effective `base + slow + plastic`, with reports for the three layers.
- `ENG.md:223-226` requires consolidation to validate slow, plastic, and the three-layer norm before submission and to reject an unrepresentable actual norm. The current checks do not cover the combined effective value.
- The existing finite tests read at `learning/consolidation_finite_test.go:26-40,42-68,90-113` cover candidate slow overflow, finite large layer norms, and unrepresentable layer norms; they do not cover the successful commit followed by combined effective overflow. These tests were not run in this audit.

**Recommended correction for the owning implementation work**

Extend the same-lock consolidation preflight to validate the effective combined weights using the exact free/fixed arithmetic used by `EffectiveWith`, including the candidate slow layer and retained plastic layer, before mutating either layer. Keep the existing candidate and per-layer norm checks.

## P0/P2 confirmed findings

No P0 or P2 defect was confirmed from the reviewed sources. The P1 label is not being upgraded to P0; this audit has source-level reachability but no dynamic severity measurement.

## NEEDS INVESTIGATION

### Potential P2 — fixed-sign `BaseL2` metric space is unspecified

- `learning/network.go:43-49`, `learning/constrained.go:133-159`, and `learning/network.go:182-194` establish that a fixed-sign core weight is stored as raw log magnitude `rho` and converted to effective `sign*exp(rho)` before the effective path.
- `plasticity/plasticity.go:490-499` explicitly expects an already-effective base. Slow and plastic are then additive effective-magnitude increments, so their units are consistent with the fixed-sign composition.
- `learning/consolidation.go:142-145` computes `BaseL2` directly from `i.trainer.parameters.Core.Weights`, which is raw `rho` for fixed-sign edges, while `SlowL2` and `PlasticL2` are computed from effective-space increments.
- Ticket 22 requires the three layer norms but does not explicitly say whether `BaseL2` is a raw-parameter norm or an effective-weight norm. If it is intended to describe the three effective layers, the fixed-sign report is dimensionally inconsistent; if raw parameter-space reporting is intentional, there is no defect. The missing decision is the metric-space definition for `ConsolidationReport.BaseL2`. No fixed-sign report assertion was executed.

The fixed/free **composition** units themselves have no confirmed mismatch: free edges add raw base, slow, and fast; fixed edges convert the base to effective signed magnitude, then add slow and fast in magnitude units and apply the floor.

## Restore / Advance boundary review

- Restore validates schema, lengths, finiteness, and fast bounds, then copies state (`learning/individual.go:196-284`); it does not preflight the combined effective weights. For P1, the relevant pre-state has finite combined arithmetic, while the earlier report-v1 example represented a state already unusable before Restore completed.
- Advance keeps stepwise neural, chemical, and fast candidates local and commits only after effective-weight, output-finiteness, and context checks (`learning/individual.go:606-618,621-623`). No partial Advance commit defect was confirmed.
- Consolidate holds the individual lock and validates before its layer mutation, but its validation boundary is incomplete for the combined effective arithmetic, as described in P1.

## Changed

| 檔案 | 變更摘要 |
|---|---|
| `runs/.tmp/slow-memory-composition-20261014/review/report.md` | 修正觸發例、補來源 SHA-256 與行號，保留 source-level 判定。 |
| `runs/.tmp/slow-memory-composition-20261014/review/report-v1.md` | 保留前一版報告的完整位元組。 |

## Actions

| 動作 | 對象 | 結果 |
|---|---|---|
| 唯讀狀態檢查 | Git working tree | `git status --short` 僅見 MOD-06 未追蹤準備／探針檔，`git diff --stat` 無 tracked source diff；未執行任何 Git 寫入。 |
| 保存舊版 | `runs/.tmp/.../review/report-v1.md` | 舊版與保存前 `report.md` 的 SHA-256 均為 `9f99b8a1aab3fd3b390f2b676b0b722e2d3182d1096134aa98012b896f511441`，`cmp` 相同。 |
| 更新報告 | 指定 `runs/.tmp/.../review/report.md` | 已修正；未寫入其他檔案。 |

## Source fingerprints and line evidence

SHA-256 是本輪實際讀取檔案的指紋；行號以同一工作樹內容核對。

| 檔案 | SHA-256 | 核對行號 |
|---|---|---|
| `AGENTS.md` | `758f8a3c7df1493297e51fe19b41fb117b77296704b1aca0be6038770ae15ba0` | 1-18, 27-34, 44-53 |
| `README.md` | `c7ec693d88e8b4fd045af14c6542eef0d73ddf57742b93d67e12300d463556d9` | 1-15 |
| `docs/initialization.md` | `19a358028e3d55985b77f76f8d5f0b35c944da2bf933b5beca7fbb574eee18ec` | 1-49 |
| `docs/handoff/AGENT_START_HERE.zh-TW.md` | `126ec9a76ed5eead27fbff3c966be00cee91fd82018f9569c72318fe27248183` | 1-47 |
| `evidence/MOD-06/slow-memory-composition-20261014/plan.md` | `dca4015838d220b133cd8af5ac40de9bf82a4d958fe55b62a72f6d638788d521` | 1-23 |
| `ENG.md` | `3c2e550fb165d3d17fe97ee555c64e009cefc7945454dc73172e5820f80b45e5` | 221-226 |
| `docs/handoff/CoImNet_Implementation_Plan.zh-TW.md` | `b92126883a10cdb9fb852276796e0521111520709bb7ca82d06f98dbab8935ea` | 458-479, 552-558 |
| `docs/tickets/18-local-plasticity.md` | `57447155d05a9ae77572908025856983af00db95d41e488fe36810f2f9ad53a2` | 20-40 |
| `docs/tickets/22-modulated-learning-memory-controller-and-interventions.md` | `2dd0e2b100f2a5232a786e99d529947c98a3b3692de245822b5ddddef312df2f` | 34-43 |
| `learning/consolidation.go` | `280ad243583b051f5ea540504ba853c66ea48056ce0ddf77c61652e8063a1982` | 83-92, 93-183, 196-214 |
| `learning/individual.go` | `f5e626c5532df1a95d1abdae3bf836784030fedba8382d63b92f2f1c32bf80e2` | 196-284, 606-623, 652-724 |
| `learning/network.go` | `56fe942df2304d60d13fe46221b43b407d8f343e6e7792258d8a7be751d2f2eb` | 43-49, 182-194 |
| `learning/constrained.go` | `a44579d841f4d628db541030e54657c278ebd2cec484c17be60f6aa6901fb728` | 133-159 |
| `plasticity/plasticity.go` | `3e663a217f018266b09776416eefa5354ced8f6230bd62f8e01851a299a2a470` | 147-163, 255-300, 490-561 |
| `learning/consolidation_finite_test.go` | `73a10e65113c5e68a5421829cf7dd823011c9ed6864a1c9f9f5025f4e7f9537d` | 12-40, 42-68, 90-113 |

## Verified

- 已核對 `evidence/MOD-06/slow-memory-composition-20261014/plan.md`、`AGENTS.md`、`README.md`、`docs/initialization.md`、`docs/handoff/AGENT_START_HERE.zh-TW.md`、`ENG.md`。
- 已核對原始手冊 §10.2、§10.4、§11.6，以及 ticket 18、ticket 22 的記憶組合與 fixed/free sign 契約。
- 已核對 live source：`learning/consolidation.go`、`learning/individual.go`、`learning/network.go`、`learning/constrained.go`、`plasticity/plasticity.go`，來源基準均為 `f69be0f82b27b327add5faae4388e25f409ea44c`。
- 判定依來源與可計算觸發值完成；未執行 Go、race、測試、網路或外部 CLI，因此沒有測試通過聲明。

## Notes

- P1 是 source-level reachable finding；尚未由本輪實際 Go 回歸重現。原先報告的 `0.75*M + 0.5*M` 只證明 Restore 可接受已無法運作的狀態，已在本版與 P1 證據分開。
- P2 的唯一缺口是 `BaseL2` 在 fixed-sign 下應採 raw `rho` 還是 effective magnitude 的正式定義。
- 本報告未修改 Go、測試、文件、資料、模型、Git 或外部設定。

## Next

- 由 root 依授權補一個以 `base=1e308, slow=-1e308, plastic=1e308`（fixed-sign 則 raw base=`log(1e308)`）為起點的 Restore → Advance → Consolidate → Advance combined-overflow 回歸，並在修正後重新驗證。
- 先決定 `ConsolidationReport.BaseL2` 的 metric space，再決定是否補 fixed-sign 報告測試。

Skills：無
