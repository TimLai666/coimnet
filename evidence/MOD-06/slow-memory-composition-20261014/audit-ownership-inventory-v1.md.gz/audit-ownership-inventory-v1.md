# `Rule` 受體索引所有權盤點

- 稽核日期：2026-10-14
- 基準 HEAD：`f69be0f82b27b327add5faae4388e25f409ea44`
- 範圍：只盤點 `plasticity.Rule.GateReceptor` 與 `DecayEReceptor` 兩個 `*int` 的輸入、輸出、快照與個體消費邊界。
- 本輪未實際執行 Go、測試、race、網路或外部模型。以下 `CONFIRMED` 是依目前來源可直接判定的來源層結果；動態重現均標為未執行。

## Problem

`plasticity.Model` 的註解宣告模型不可變，`Model.Config` 的註解宣告回傳獨立副本；但 `Rule` 內兩個受體索引是指標。`New` 與 `Config` 都只複製 `Rule` 結構，不複製指標指向的 `int`，所以呼叫端仍能改動模型宣告。`Individual` 的 Snapshot 又把同一批指標帶出，Restore 也沒有補上受體數量的交叉檢查。

## Done

已核對 `New`、`Model.Config`、`Individual.EnablePlasticity`、`Snapshot`、`RestoreIndividual`、`EnableChemistry` 與 `advanceStepwise` 的實際讀寫位置，並和其他設定型指標的深拷貝慣例比較。未修改來源、測試、追蹤文件或 Git。

## CONFIRMED

### C-1：`New` 輸入與 `Model.Config` 輸出都保留兩個 `*int` 的別名

證據：

- `plasticity/plasticity.go:66-82` 定義 `GateReceptor *int` 與 `DecayEReceptor *int`。
- `plasticity/plasticity.go:117-125` 宣告 `Model` 是 immutable rule；`New` 的明示獨立副本承諾只涵蓋 edge selection，沒有涵蓋 `Rule` 內的指標。
- `plasticity/plasticity.go:126-144` 的 `New` 以 `rule: c.Rule` 儲存結構副本，只對 `Edges` 使用 `append` 深拷貝；兩個 `*int` 沒有被複製。
- `plasticity/plasticity.go:167-193` 的 `validateRule` 只讀取當下指標值並驗證負值與相關欄位，不建立所有權副本。
- `plasticity/plasticity.go:227-232` 的 `Config` 以 `Rule: m.rule` 回傳結構副本，只對 `Edges` 使用 `append`；兩個 `*int` 仍指向模型原本的 `int`。

最小觸發是合法建立後改變指標所指的值：

```go
gate, decay := 0, 0
// cfg.Rule 其餘欄位與邊選擇先填成合法值。
model, _ := plasticity.New(cfg, edgeCount)
gate = -1
```

此時 `model.Config().Rule.GateReceptor` 會看到 `-1`。反向地，先取得 `out := model.Config()` 再執行 `*out.Rule.GateReceptor = -1`，也會改變模型後續 `Config` 看到的值。重新指定 `cfg.Rule.GateReceptor` 或 `out.Rule.GateReceptor` 這個結構欄位本身不會改到模型，缺陷是兩個指標的 pointee 沒有隔離。

影響是後續 `GateFor`／`WindowFor` 與個體逐步路徑讀到的宣告可以在建構驗證後被外部改變，違反 immutable／independent-copy 契約。這是來源層已確認的所有權缺陷，不依賴模型任務品質推測。

### C-2：Individual 的 Enable、Snapshot、Restore 沿用同一個別名

- `learning/individual.go:129-133` 明示 construction、snapshots 與 outputs 不保留 caller-owned mutable buffers。
- `learning/individual.go:286-301` 的 `newPlasticRuntime` 將 `plasticity.Config` 傳給 `plasticity.New`，因此承接 C-1 的 `Rule` 指標別名。
- `learning/individual.go:304-325` 的 `EnablePlasticity` 在 `321-323` 只用當下的 `c.Rule` 呼叫 `checkReceptorRule`，成功後把 runtime 存入個體；沒有把兩個指標複製成模型所有的值。啟用後修改原始 `*int`，模型宣告仍會被改動。
- `learning/individual.go:328-352` 的 `checkReceptorRule` 只在該次檢查讀取受體值；`learning/individual.go:291-316` 的 `EnableChemistry` 也只在切換化學層時檢查一次 `i.plastic.model.Config().Rule`，沒有持續保護別名。
- `learning/individual.go:394-426` 的 `Snapshot` 標示為 independent copy，但 `405` 直接把 `i.plastic.model.Config()` 放入 `PlasticPart.Config`。由於 C-1 的淺拷貝，快照的兩個指標仍與 live model 共用。
- `learning/individual.go:1006-1019` 的 `copyPlasticState` 只深拷貝 fast state 陣列，沒有 Rule 複製步驟。
- `learning/individual.go:194-243` 的 `RestoreIndividual` 在 `228-241` 以快照的 `Plastic.Config` 呼叫 `newPlasticRuntime`，只複製 state，沒有複製兩個 `*int`；`244-283` 隨後才恢復化學，整段沒有對塑性規則再呼叫 `checkReceptorRule`。

因此存在兩條來源可達的失效路徑：

1. 已啟用合法受體規則的個體，其輸入指標在啟用後被改成 `-1` 或超過化學受體數量，下一次含化學層的 Advance 仍會使用該值。
2. `Snapshot` 取得的 `Plastic.Config` 指標被改值時，因為和 live model 共用 pointee，會同步改變原個體；以該快照 Restore 的個體也會再承接同一個輸入指標。

### C-3：Restore 可放行非負但超出受體數量的索引，Advance 直接索引

- `plasticity/plasticity.go:167-180` 對兩個受體指標只拒絕 `< 0`，沒有依化學受體數量做上界檢查。
- `learning/individual.go:228-241` 的 Restore 塑性分支先建立 model、驗證 fast state／slow state 就提交 `restored.plastic`；`learning/individual.go:244-282` 恢復化學分支時沒有回頭驗證受體索引與 `len(Chemistry.Receptors.Records)` 的關係。
- `learning/chemistry.go:235-263` 配置 `chemicalRow.receptorOccupancy` 的長度等於受體紀錄數。
- `learning/individual.go:742-793` 的 `advanceStepwise` 在 `773-775` 與 `786-788` 直接用 `chemical.receptorOccupancy[*rule.GateReceptor]`／`[*rule.DecayEReceptor]`，沒有 bounds check；`i.chemical != nil` 時此索引會在每個相關步驟被消費。

在其他快照欄位都合法、化學只有一筆受體、規則索引為非負 `1` 的前提下，來源沒有拒絕這個越界值，後續含化學的 Advance 會走到越界 slice index。這個 panic 路徑由來源控制流可判定，但本輪沒有執行 Restore 或 Advance 動態重現，不能寫成已觀察到的 runtime panic。

## NEEDS INVESTIGATION

- 本輪沒有執行上述 caller mutation、Snapshot mutation 或 out-of-range Restore 的 Go probe；Root 提供的 `Model.New`／`Config` 四案例結果屬外部執行證據，不算本檔的實際執行。
- 需要下一票決定並驗證兩個邊界的修正契約：`New` 是否在存入 model 前複製 pointee、`Config`／Snapshot／Restore 是否各自產生新的 `int`，以及既有 JSON 快照的相容性處理。這輪不改 code、不自定新政策。
- 需要動態確認 Restore 的完整公開輸入在其他欄位合法時確實可形成「一筆受體、索引 1」的快照並抵達 Advance；來源已顯示缺少決定性的交叉檢查，但這個 runtime 結果尚未由本輪執行。
- 沒有化學層時 Advance 的兩個索引分支因 `i.chemical != nil` 條件不會取用 `receptorOccupancy`；這只限制該次 panic 觸發，不解除宣告仍可被外部改動的所有權缺陷。

## 同類型深拷貝慣例

目前專案已有把設定型指標交給 immutable model 擁有、並在輸出副本再複製的慣例：

| 來源 | 行號 | 慣例 |
| --- | --- | --- |
| `dynamics/lif.go` | `175-178`, `258-271` | `NewLIF` 把 `Homeostasis *LIFHomeostasis` 複製成 owned block；`Config` 再複製一次，明示 independent copy。 |
| `dynamics/mixed.go` | `197-208`, `229-243` | Mixed 建構沿用 `NewLIF` 的 owned block，`Config` 複製 `Homeostasis`。 |
| `learning/constrained.go` | `392-411` | `copyOptions` 深拷貝所有 optional pointer（實作包含 Masks、Ranges、Schedule、Recompute）。 |
| `learning/memory.go` | `92-100` | `copyExpression` 複製 `ExpressionGain` 與其 `Nodes` slice，避免 snapshot／runtime 共用。 |
| `modulation/config.go` | `38-40`, `151-176`, `279-313` | `Build`／`clone`／`ChemistryConfig.Clone` 明示並實作 nested pointer 與 buffer 的獨立副本。 |

這些慣例支持本票契約判定：`GateReceptor` 與 `DecayEReceptor` 也應由 immutable `Model` 擁有，輸入或 `Config` 副本的 pointee 變更不應改動模型後續宣告。這是所有權判定，不是對模型準確率的推測。

## 原始契約與核對來源

| 來源 | 行號 | 用途 | 本次檔案 SHA-256 |
| --- | --- | --- | --- |
| `docs/tickets/22-modulated-learning-memory-controller-and-interventions.md` | `23-28`, `42-43` | 受體索引欄位、建構驗證與快照恢復契約 | `2dd0e2b100f2a5232a786e99d529947c98a3b3692de245822b5ddddef312df2f` |
| `docs/model-and-mechanisms.md` | `55-57` | 受體驅動 Gate／Decay 與快照／慢速機制定位 | `43d9e559e9c25ea8767d0e65e9bb920406258cb3975912b21d9490b347184d61` |
| `ENG.md` | `215`, `223` | 可變來源複製、操作邊界與本票工程契約 | `c705912363988e378ba1b39d1a546440f61116336c333ac6816a7ded9c575a15` |
| `evidence/MOD-06/slow-memory-composition-20261014/plan.md` | `11-17`, `25-27` | 本輪 read-only 稽核範圍與 Root 修正責任界線 | `49b99cb63591c1552e86726da268c4149c8c97e12d240fa6193f4a4f2026e435` |

## Source fingerprints

以下 SHA-256 是本次讀取到的工作樹檔案 bytes。`plasticity/plasticity.go` 目前含 Root 未提交的既有修改，本檔沒有改它。

| 檔案 | 主要行號 | SHA-256 |
| --- | --- | --- |
| `plasticity/plasticity.go` | `66-82`, `117-144`, `167-193`, `227-232`, `462-491` | `ca835416a04696cfb70122b74d1763d2c201d3a732af1c9c29685237e04dbd9f` |
| `learning/individual.go` | `129-133`, `194-243`, `286-352`, `394-426`, `652-793`, `1006-1019` | `f5e626c5532df1a95d1abdae3bf836784030fedba8382d63b92f2f1c32bf80e2` |
| `learning/chemistry.go` | `144-153`, `235-265`, `291-316` | `4e6164cbafd843c56c357558e9b8a580598b607daeccffbfc74a714052a52032` |
| `dynamics/lif.go` | `15-39`, `175-178`, `258-272` | `95b4fd8f3c098f6ff49693f7025e2e91b6fd8394fede837d81fcdfbc3e84ec5f` |
| `dynamics/mixed.go` | `197-208`, `229-244` | `3d7741a6db48c31039d1fb50036ef24f24822db8ba5e29c0459bef5aae3d96f4` |
| `learning/core.go` | `531-544` | `fbf4f8238b352a9b6351c5207b92c9b0c4e30e50fd8e2b7dce507ced0855ece8` |
| `learning/constrained.go` | `392-411` | `a44579d841f4d628db541030e54657c278ebd2cec484c17be60f6aa6901fb728` |
| `learning/memory.go` | `92-100` | `e43731d6ccecbbfc6c597be869bc9e6f499fa67d7a8332d1bae01eeec02e87d7` |
| `modulation/config.go` | `38-40`, `151-176`, `279-313` | `888441fa39463afe1afe0fb28c8e008d23c55f5e6b8e6aab171e4fd434928a01` |

## Verified

- 已唯讀核對上述來源、行號與 SHA-256。
- 已唯讀檢查 `git status --short` 與 `git diff --stat`；未執行任何 Git 寫入。
- 未執行 Go、測試、race、網路或外部模型，因此沒有任何 runtime pass／fail 聲明。

## Changed

| 檔案 | 變更摘要 |
| --- | --- |
| `runs/.tmp/slow-memory-composition-20261014/review/ownership-inventory.md` | 新增本次 `Rule` 受體索引所有權盤點。 |

## Actions

| 動作 | 對象 | 結果 |
| --- | --- | --- |
| 唯讀來源與指紋核對 | CoImNet 工作樹 | 完成，未改來源。 |
| Git 狀態／差異統計 | CoImNet 工作樹 | 完成，未執行 add、commit、push、stash、reset。 |

## Notes

本檔確認的是指標所有權與來源可達的消費風險，不重新評估 Root 本輪慢速記憶修正的數值結果，也不把未執行的動態路徑寫成已通過。

## Next

下一票應先決定並以最小公開驗證固定 `Rule` 兩個指標的 deep-copy 邊界，再處理 Restore 的受體數量交叉檢查與 Advance 的失敗形式；本輪不改 code。

Skills：無
