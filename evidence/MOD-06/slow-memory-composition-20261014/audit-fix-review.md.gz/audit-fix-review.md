# MOD-06 consolidation fix diff review

- Baseline `HEAD`: `f69be0f82b27b327add5faae4388e25f409ea44c`.
- Reviewed diff: `learning/consolidation.go` and `plasticity/plasticity.go` only.
- This audit is read-only. I did not run Go, tests, network access, or Git writes. Root's probe and test records below are read as external evidence and are not claimed as executions by this audit.

## Problem

Review the uncommitted consolidation fix against the live effective-weight contract: fixed raw `rho` conversion, enabled-position to core-edge mapping, no candidate edge-array allocation, fixed-floor handling of negative values, original norm/context refusal order, and atomic no-commit behavior. Separately track any confirmed `Model.Config` pointer aliasing.

## Done

No defect was confirmed in the two-file fix for the requested consolidation invariants. The implementation matches the existing effective-weight arithmetic and keeps the write behind all relevant refusal checks. Root's severity classification for the original bug is consistent with the evidence: **P2**, limited to extreme finite layer values; this review does not upgrade it.

## CONFIRMED findings

### Main fix: no confirmed regression

- **Fixed raw `rho` conversion:** `learning/consolidation.go:167-176` reads the stored raw core value and applies `math.Exp` only when the configured edge sign is nonzero. This matches `learning/constrained.go:133-159`, where fixed-sign raw `rho` maps to positive magnitude, and `learning/network.go:182-194`, where the core receives the signed effective value. `EffectiveWith` uses `math.Abs` on that already-effective signed base (`plasticity/plasticity.go:546-555`), so using positive `exp(rho)` for the consolidation magnitude is equivalent for both `+1` and `-1` signs.
- **Enabled position mapping:** `plasticity.Model.Edge` returns `m.edges[position]` and `m.rule.WMin` without exposing the selection (`plasticity/plasticity.go:243-255`). Consolidation then indexes `EdgeSigns` with the returned core edge (`learning/consolidation.go:163-170`). This avoids treating a sparse enabled position as a core edge index. Root's recorded `TestEdgeMetadataUsesEnabledPosition` passed in `composition-green.log:3-8` and its source is `plasticity/edge_test.go:9-29`.
- **No new edge arrays:** the preflight scan at `learning/consolidation.go:155-180` uses scalar locals (`candidate`, `retained`, `edge`, `wMin`, `base`, `weight`) and the second scan at `learning/consolidation.go:191-198` performs the existing in-place write. `Model.Edge` returns scalars and does not allocate. No candidate slow/plastic/effective slice was added.
- **Fixed-floor control:** the arithmetic is `(base + candidate) + retained`, then the fixed floor is applied when the magnitude is below `wMin` (`learning/consolidation.go:172-180`). This is the same order and floor placement as `EffectiveWith` (`plasticity/plasticity.go:546-558`). A negative finite value below the floor and a negative overflow both satisfy `weight < wMin`; NaN remains an error because the comparison is false and `!finite(weight)` is checked. Root's recorded six fixed-sign floor controls passed (`composition-green.log:282-309`), covering continuous/LIF/mixed and both signs.
- **Norm/context/error order and atomicity:** the original per-layer norm refusal remains before the context check (`learning/consolidation.go:182-187`); the new combined-weight error is checked after context (`learning/consolidation.go:188-190`). Thus norm still wins over context, context still wins over the new effective error, and no commit occurs before either check. The commit remains only at `learning/consolidation.go:191-199`. The new composition test asserts snapshot equality after a combined-overflow refusal (`learning/consolidation_composition_test.go:90-101`). Existing finite norm tests assert no mutation (`learning/consolidation_finite_test.go:26-40,90-113`).

Root's **pre-fix** public-probe record reports the original external behavior for all three signs: `Retain=1` applies consolidation and the next `Advance` reports the non-finite effective-weight error, while `Retain=0` has no next-advance error (`public-probe-v4.json:1-25`, `public-probe-v4.log:1-6`). It is evidence for the original defect, not post-fix behavior. The record has exit code 0, but I did not execute it.

### Adjacent confirmed tracking issue: `Model.Config` aliases the two rule pointers

This is outside the current diff and is not fixed here.

- `Rule` exposes `GateReceptor *int` and `DecayEReceptor *int` (`plasticity/plasticity.go:62-83`). `Model` stores `rule Rule` by value (`plasticity/plasticity.go:117-122`), but `Config()` returns `Rule: m.rule` without cloning those pointed-to integers (`plasticity/plasticity.go:227-233`).
- The comment promises an independent copy, yet a caller can mutate the returned pointer and change the supposedly immutable model. Later `StepWith`/`WindowFor` reads the internal pointers (`plasticity/plasticity.go:344-349,462-490`), so this is a real public aliasing path, not only a documentation concern.
- Minimal public verification, not run here:

  ```go
  gate := 0
  m, _ := plasticity.New(plasticity.Config{
      Rule: plasticity.Rule{Kind: plasticity.RuleHebbianRate, DecayE: .5, DecayP: .5,
          PlasticMax: 1, WMin: .1, GateReceptor: &gate},
      Edges: []int{0},
  }, 1)
  c := m.Config()
  *c.Rule.GateReceptor = 7
  // A genuinely independent Config would leave *m.Config().Rule.GateReceptor == 0;
  // the current implementation observes 7.
  ```

Track this separately as an API immutability/alias-isolation issue. No new `BaseL2` metric policy is inferred from it.

## NEEDS INVESTIGATION

- This audit did not independently execute the public probe, the targeted test command, or the broader regression/race suites. Root's recorded `composition-green.json:1-21` reports exit code 0 for the targeted command; that record is evidence to review, not an execution claim by this audit.
- The source-level fixed conversion assumes the raw `rho` is already a representable validated parameter. `EffectiveWeights` rejects `exp(rho) == 0` (`learning/constrained.go:133-159`), while `minLogMagnitude` only rejects non-finite or too-large floors (`learning/constrained.go:179-191`). No dynamic check was performed for a malformed or separately introduced underflowed raw `rho`; this is not a confirmed defect in the reviewed diff because normal New/Step/Restore candidate validation is intended to reject such a state.
- Context cancellation winning over a simultaneous combined overflow was verified by source order only. The existing evidence reviewed here covers normal targeted runs and no-commit assertions, not an injected cancellation at the exact preflight boundary.
- `baseL2` still calls `l2(i.trainer.parameters.Core.Weights)` (`learning/consolidation.go:152`), so fixed-sign entries are measured in stored raw `rho` units while the combined-weight check converts them with `exp(rho)`. The source contract says the three L2 values are reported separately but does not resolve raw versus effective units; this audit leaves that metric decision open.
- The pointer-alias issue has a source-level trigger and minimal public check above, but no dynamic execution or compatibility decision was made.

## Changed

| 檔案 | 變更摘要 |
|---|---|
| `runs/.tmp/slow-memory-composition-20261014/review/fix-review.md` | 新增唯讀 diff 稽核報告。 |

## Actions

| 動作 | 對象 | 結果 |
|---|---|---|
| 唯讀 diff 檢查 | `learning/consolidation.go`, `plasticity/plasticity.go` | 讀取 25 行新增／1 行修改與 14 行新增；未改來源。 |
| 唯讀證據檢查 | MOD-06 public probe／targeted test records | 讀取 Root 產出的 JSON、log 與測試來源；未重跑。 |
| Git 狀態檢查 | working tree | 確認兩個來源檔有未提交修改；未執行 Git 寫入。 |

## Source fingerprints and line evidence

SHA-256 是本輪實際讀取的檔案指紋；來源修改檔的 SHA 是目前工作樹內容，基準 commit 為上列 `HEAD`。

| 檔案 | SHA-256 | 核對行號 |
|---|---|---|
| `learning/consolidation.go` | `061ae734c1e921da493c052581143a9d4908c1af47a98a848a4c5ffeaeb350df` | 150-205 |
| `plasticity/plasticity.go` | `ca835416a04696cfb70122b74d1763d2c201d3a732af1c9c29685237e04dbd9f` | 62-83, 117-122, 227-255, 330-406, 462-490, 490-561 |
| `learning/constrained.go` | `a44579d841f4d628db541030e54657c278ebd2cec484c17be60f6aa6901fb728` | 133-159, 179-191 |
| `learning/network.go` | `56fe942df2304d60d13fe46221b43b407d8f343e6e7792258d8a7be751d2f2eb` | 182-194 |
| `learning/consolidation_composition_test.go` | `4622c659e33a063e66f1da5c5a7598471afdbc1e5865b2748acb51ba7f197823` | 73-106, 140-190 |
| `plasticity/edge_test.go` | `1ebe34c69521e298d66675480ed8012fc74007c7844457e198eba0d82a61a284` | 9-29 |
| `evidence/MOD-06/slow-memory-composition-20261014/plan.md` | `4249e2ccceb13eb87d3171d3670db691a4b4ecfd55786f8424fd71a54788f673` | 13-17, 25-28 |
| `ENG.md` | `3c2e550fb165d3d17fe97ee555c64e009cefc7945454dc73172e5820f80b45e5` | 223-225 |
| `docs/tickets/22-modulated-learning-memory-controller-and-interventions.md` | `2dd0e2b100f2a5232a786e99d529947c98a3b3692de245822b5ddddef312df2f` | 34-43, 55-57 |
| `docs/model-and-mechanisms.md` | `43d9e559e9c25ea8767d0e65e9bb920406258cb3975912b21d9490b347184d61` | 57 |
| `evidence/MOD-06/slow-memory-composition-20261014/public-probe-v4.json` | `0616f5cb0b27e2e3bbaad2133369d245f3917b815af7375959552d6a36181e7e` | 1-26 |
| `evidence/MOD-06/slow-memory-composition-20261014/public-probe-v4.log` | `fe5985c2b661308521dadce7b6d4f892f77fa17ed7bafaff4181f56b940c2475` | 1-6 |
| `evidence/MOD-06/slow-memory-composition-20261014/composition-green.json` | `ecc780a0d94b93e3859247cc75db168ad850cef69dacef8219ecf461405df9f5` | 1-21 |
| `evidence/MOD-06/slow-memory-composition-20261014/composition-green.log` | `8ebc7b8f7fa0d045273f86cb69946f0597219695d443f200124312a8f1b62343` | 3-8, 282-309 |

## Verified

- The implementation maps enabled positions to core edges before reading signs, applies `exp(rho)` only for fixed signs, and mirrors `EffectiveWith` operation order and floor semantics.
- The implementation performs no candidate edge-array allocation and commits only after candidate, norm, context, and combined-effective checks.
- Root's recorded targeted run includes the 12 profile/sign rejection cases, 54 finite reference combinations, and six fixed-floor controls. I read the records but did not run them.
- No source, test, report, or Git file was modified by this audit except the specified `fix-review.md`.

## Notes

- Main fix conclusion: no confirmed regression; root's main issue severity remains P2.
- The `Model.Config` pointer alias is a separate confirmed tracking issue. It is intentionally not fixed in this review.
- The underflowed raw-rho boundary and exact context-cancellation precedence remain unexecuted.

## Next

- Track and separately decide the `Model.Config` deep-copy contract for `GateReceptor` and `DecayEReceptor`.
- Root can run the full required Go/build/race/vet validation after deciding whether the pointer-alias issue belongs in this or a later ticket.

Skills：無
