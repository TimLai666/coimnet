package main
import (
 "context"
 "encoding/json"
 "fmt"
 "math"
 "os"
 "reflect"
 "github.com/TimLai666/coimnet/dynamics"
)
func must(e error){if e!=nil {panic(e)}}
type sequence struct{}
func(sequence) Forward(context.Context,int,[]float64)(*dynamics.Modulation,error){return &dynamics.Modulation{},nil}
func(sequence) NewReverse(context.Context,int,int)(dynamics.ModulationReverse,error){return sequence{},nil}
func(sequence) BackwardStep(context.Context,int,dynamics.ModulationGradient)([]dynamics.ActivityGradient,error){return nil,nil}
func(sequence) Checkpoint(context.Context,int)(dynamics.ModulationRestart,error){return func(context.Context)(dynamics.ModulationSequence,error){return sequence{},nil},nil}
func main(){
 ctx:=context.Background()
 c:=dynamics.LIFConfig{Nodes:2,DT:3,TauSyn:1,ThetaMin:0,ThetaMax:2,VReset:-1,Surrogate:dynamics.LIFSurrogate{Kind:"fast_sigmoid",Scale:1},Homeostasis:&dynamics.LIFHomeostasis{Enabled:true,TauRate:1,TargetRate:.25,Eta:1e-308,HMax:.4}}
 p:=dynamics.LIFParameters{Bias:[]float64{0,0},LogTau:[]float64{0,0},ThetaRaw:[]float64{0,0}}
 initial:=[]float64{0,0};in:=make([][]float64,1023);up:=make([][]float64,1023)
 for i:=range in {in[i]=[]float64{0,0};up[i]=[]float64{0,0}}
 in[0][0]=4;in[1021][0]=1.2
 m,e:=dynamics.NewLIF(c);must(e)
 base,e:=m.Forward(ctx,p,initial,in);must(e);want:=base.Outputs()
 for t,row:=range base.Spikes(){expected:=0.0;if t==0 {expected=1};if row[0]!=expected || row[1]!=0 {panic(fmt.Sprint("unexpected spike",t,row))}}
 calls:=0
 equal:=func(label string,out [][]float64,e error){must(e);if !reflect.DeepEqual(out,want){panic(label+" output mismatch")};calls++}
 tr,e:=m.ForwardCoupled(ctx,p,initial,in,sequence{});must(e);equal("coupled",tr.Outputs(),nil)
 s,e:=m.NewState(initial);must(e);s,out,_,e:=m.Advance(ctx,p,s,in);equal("advance",out,e)
 if s.Rate[0]!=math.Ldexp(3,1022) || s.Homeostasis[0]!=.4 {panic(fmt.Sprint("final state mismatch",s.Rate,s.Homeostasis))}
 for _,seg:=range []int{1,17,1022}{
  out,e:=m.ForwardRecompute(ctx,p,initial,in,seg);equal("recompute",out,e)
  _,e=m.BackwardRecompute(ctx,p,initial,in,up,0,seg);must(e)
  cr,e:=m.ForwardCoupledRecompute(ctx,p,initial,in,sequence{},seg);must(e);equal("coupled recompute",cr.Outputs(),nil)
  _,e=m.BackwardCoupledRecompute(ctx,cr,up,0);must(e)
 }
 mc:=dynamics.MixedConfig{Nodes:2,DT:3,NodeRule:[]uint8{dynamics.RuleLIF,dynamics.RuleContinuous},Continuous:dynamics.ContinuousRule{Activation:"tanh"},LIF:dynamics.LIFRule{TauSyn:1,ThetaMin:0,ThetaMax:2,VReset:-1,Surrogate:c.Surrogate,Homeostasis:c.Homeostasis}}
 mm,e:=dynamics.NewMixed(mc);must(e);mp:=dynamics.MixedParameters{Bias:p.Bias,LogTau:p.LogTau,ThetaRaw:[]float64{0}}
 mt,e:=mm.Forward(ctx,mp,initial,in);must(e);equal("mixed",mt.Outputs(),nil)
 mt,e=mm.ForwardCoupled(ctx,mp,initial,in,sequence{});must(e);equal("mixed coupled",mt.Outputs(),nil)
 ms,e:=mm.NewState(initial);must(e);ms,out,_,e=mm.Advance(ctx,mp,ms,in);equal("mixed advance",out,e)
 if ms.LIF.Rate[0]!=s.Rate[0] || ms.LIF.Homeostasis[0]!=s.Homeostasis[0] {panic("mixed final state mismatch")}
 off:=c;h:=*c.Homeostasis;h.Eta=0;off.Homeostasis=&h;om,e:=dynamics.NewLIF(off);must(e);ot,e:=om.Forward(ctx,p,initial,in);must(e)
 if want[1021][0]!=0 || ot.Spikes()[1021][0]!=1 {panic("homeostasis ablation inactive")}
 longer:=append(append([][]float64(nil),in...),[]float64{0,0});rejections:=0
 reject:=func(trace any,e error){if e==nil {panic("true overflow accepted")};v:=reflect.ValueOf(trace);if v.IsValid() && !v.IsNil(){panic("failed call published partial results")};rejections++}
 reject(m.Forward(ctx,p,initial,longer))
 reject(m.ForwardCoupled(ctx,p,initial,longer,sequence{}))
 for _,seg:=range []int{1,17,1022}{reject(m.ForwardRecompute(ctx,p,initial,longer,seg));reject(m.ForwardCoupledRecompute(ctx,p,initial,longer,sequence{},seg))}
 reject(mm.Forward(ctx,mp,initial,longer));reject(mm.ForwardCoupled(ctx,mp,initial,longer,sequence{}))
 must(json.NewEncoder(os.Stdout).Encode(map[string]any{"equal_output_paths":calls,"true_overflow_rejections":rejections,"rate":s.Rate[0],"h":s.Homeostasis[0],"probe_event_with_homeostasis":base.Spikes()[1021][0],"probe_event_without_homeostasis":ot.Spikes()[1021][0],"steps":len(in),"purpose":"observable large-rate checkpoint and replay parity; no task-quality claim"}))
}
