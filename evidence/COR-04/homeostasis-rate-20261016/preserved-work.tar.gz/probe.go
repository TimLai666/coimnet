package main
import (
 "context"
 "encoding/json"
 "fmt"
 "math"
 "os"
 "github.com/TimLai666/coimnet/dynamics"
)
func main() {
 c := dynamics.LIFConfig{Nodes:1, DT:2, TauSyn:1, ThetaMin:0, ThetaMax:2, VReset:-1, Surrogate:dynamics.LIFSurrogate{Kind:"fast_sigmoid",Scale:1}, Homeostasis:&dynamics.LIFHomeostasis{Enabled:true,TauRate:1,TargetRate:0,Eta:0.5,HMax:0.4}}
 m,e:=dynamics.NewLIF(c); if e!=nil {panic(e)}
 p:=dynamics.LIFParameters{Bias:[]float64{0},LogTau:[]float64{0},ThetaRaw:[]float64{0}}
 s,e:=m.NewState([]float64{0}); if e!=nil {panic(e)}
 s.Rate[0]=1e308
 v:=m.ValidateState(s)
 n,_,_,e:=m.Advance(context.Background(),p,s,[][]float64{{0}})
 q,rate,event:=2.0,s.Rate[0],0.0
 product:=q*(event-rate)
 j:=map[string]any{"valid_state":v==nil,"advance_error":fmt.Sprint(e),"unfused_product":fmt.Sprint(product),"unfused_sum":fmt.Sprint(rate+product),"fma_sum":math.FMA(q,event-rate,rate),"input_rate_after":s.Rate[0],"expected_rate":-1e308}
 if e==nil {j["actual_rate"]=n.Rate[0];j["actual_h"]=n.Homeostasis[0]}
 if e:=json.NewEncoder(os.Stdout).Encode(j);e!=nil {panic(e)}
}
