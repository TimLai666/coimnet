package main
import("encoding/json";"os";"github.com/TimLai666/coimnet/replay")
func main(){var out []map[string]any
for _,kind:=range []string{"all retained unique tasks","drop with no removed item"}{
 b:=replay.Buffer{Capacity:2,Sampling:replay.SamplingTaskBalanced,Eviction:replay.EvictionFIFO,Seed:37,Privacy:replay.PrivacyPolicy{StoreRaw:true,Retention:replay.RetentionKeepUntilEvicted}}
 if kind=="drop with no removed item"{b.Sampling=replay.SamplingUniform;b.Privacy.Retention=replay.RetentionDropAfterSample}
 s,e:=replay.New(b);if e!=nil{panic(e)}
 for i:=range 2{task:="a";if i==1{task="b"};if e=s.Add(replay.Experience{TaskID:task,Step:uint64(i),Input:[][]float64{{1}},Target:[][]float64{{1}},Weight:1,Split:replay.SplitTrain});e!=nil{panic(e)}}
 snapshot:=s.Snapshot();if snapshot.State.Draws!=0 || snapshot.State.Seen!=uint64(len(snapshot.State.Items)){panic("invalid control")};snapshot.State.Draws=1
 restored,e:=replay.RestoreSnapshot(snapshot);msg:="";if e!=nil{msg=e.Error()};out=append(out,map[string]any{"kind":kind,"accepted":e==nil&&restored!=nil,"error":msg})
};if e:=json.NewEncoder(os.Stdout).Encode(out);e!=nil{panic(e)}}
