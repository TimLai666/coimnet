package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/TimLai666/coimnet/checkpoint"
	"github.com/TimLai666/coimnet/internal/delayedfixture"
	"github.com/TimLai666/coimnet/replay"
)

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func digest(value any) string {
	b, err := json.Marshal(value)
	must(err)
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:])
}
func experience(task string, step uint64) replay.Experience {
	return replay.Experience{TaskID: task, Step: step, Input: [][]float64{{float64(step) / 10}}, Target: [][]float64{{float64(step) / 20}}, Weight: 1, Split: replay.SplitTrain}
}

type sample struct {
	Items  []replay.Experience
	Report replay.SampleReport
}

func continuation(store *replay.Store) string {
	var samples []sample
	for round := range 3 {
		must(store.Add(experience("continued", uint64(100+round))))
		items, report, err := store.Sample(1 + round%2)
		must(err)
		samples = append(samples, sample{items, report})
	}
	return digest(struct {
		Samples []sample
		State   replay.State
		Report  replay.Report
	}{samples, store.State(), store.Report()})
}

type row struct {
	Name            string
	CheckpointSHA   string
	TrainingSHA     string
	ContinuationSHA string
}

func main() {
	if len(os.Args) != 3 || (os.Args[1] != "create" && os.Args[1] != "resume") {
		panic("usage: old-replay create|resume DIRECTORY")
	}
	mode, dir := os.Args[1], os.Args[2]
	if mode == "create" {
		must(os.Mkdir(dir, 0700))
	}
	var rows []row
	index := 0
	for _, sampling := range []string{replay.SamplingUniform, replay.SamplingTaskBalanced, replay.SamplingTimeBalanced} {
		for _, eviction := range []string{replay.EvictionFIFO, replay.EvictionReservoir} {
			for _, retention := range []string{replay.RetentionKeepUntilEvicted, replay.RetentionDropAfterSample} {
				for _, raw := range []bool{false, true} {
					name := fmt.Sprintf("%s/%s/%s/raw=%v", sampling, eviction, retention, raw)
					path := filepath.Join(dir, fmt.Sprintf("%02d.json", index))
					index++
					var state checkpoint.State
					var store *replay.Store
					var err error
					if mode == "create" {
						trainer, e := delayedfixture.NewDelayedTrainer(7, .01, false)
						must(e)
						state, e = checkpoint.NewState(trainer.Snapshot(), 1001, 0)
						must(e)
						store, e = replay.New(replay.Buffer{Capacity: 3, Sampling: sampling, Eviction: eviction, Seed: 37, Privacy: replay.PrivacyPolicy{StoreRaw: raw, Retention: retention}})
						must(e)
						for step := uint64(1); step <= 4; step++ {
							must(store.Add(experience(fmt.Sprintf("task%d", step%2), step)))
						}
						_, _, e = store.Sample(1)
						must(e)
						snapshot := store.Snapshot()
						state.Replay = &snapshot
						must(checkpoint.Save(context.Background(), path, state))
					} else {
						state, err = checkpoint.Load(context.Background(), path)
						must(err)
						if state.Replay == nil {
							panic("checkpoint lost replay")
						}
						store, err = replay.RestoreSnapshot(*state.Replay)
						must(err)
					}
					bytes, e := os.ReadFile(path)
					must(e)
					sum := sha256.Sum256(bytes)
					rows = append(rows, row{name, hex.EncodeToString(sum[:]), digest(state.Training), continuation(store)})
				}
			}
		}
	}
	must(json.NewEncoder(os.Stdout).Encode(rows))
}
