package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"math/big"
	"reflect"

	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/learning"
	"github.com/TimLai666/coimnet/modulation"
	"github.com/TimLai666/coimnet/plasticity"
)

func exactNorm(values []float64) float64 {
	sum := new(big.Float).SetPrec(8192)
	term := new(big.Float).SetPrec(8192)
	for _, value := range values {
		term.SetFloat64(value)
		term.Mul(term, term)
		sum.Add(sum, term)
	}
	sum.Sqrt(sum)
	result, _ := sum.Float64()
	return result
}

func run(name string, weights []float64) error {
	c := learning.Config{Dynamics: dynamics.Config{Nodes: 1, Sources: []int{0, 0}, Targets: []int{0, 0}, Delays: []int{1, 2}, DT: 1, Activation: "tanh"}, InputSize: 1, OutputSize: 1, InputNodes: []int{0}, ReadoutNodes: []int{0}}
	p := learning.Parameters{Core: dynamics.Parameters{Weights: weights, Bias: []float64{0}, LogTau: []float64{0}}, Encoder: []float64{1}, Readout: []float64{1}}
	a, err := learning.NewIndividual(c, p, learning.DefaultOptions(), []float64{0})
	if err != nil {
		return err
	}
	if err = a.EnablePlasticity(plasticity.Config{Rule: plasticity.Rule{Kind: plasticity.RuleHebbianRate, DecayE: .5, DecayP: .5, PlasticMax: 2, WMin: .01}, Edges: []int{0, 1}}); err != nil {
		return err
	}
	if err = a.EnableChemistry(modulation.ChemistryConfig{Chemistry: modulation.Chemistry{Regions: 1, Channels: 1, DT: 1, Tau: []float64{1}}, Sources: []modulation.SourceSpec{{Kind: modulation.SourceExternalTimeline, Timeline: &modulation.ExternalTimeline{ChannelCount: 1}}}, Regions: modulation.RegionAssignment{NodeRegion: []int{0}}, Receptors: modulation.Receptors{Records: []modulation.Receptor{{Cells: []int{0}, Signal: "engineering", Status: modulation.StatusHypothesized, Kd: 1, N: 1, Evidence: "report boundary probe", MeasurementKind: "engineering declaration", MappingVersion: "consolidation-norm/v1"}}}}); err != nil {
		return err
	}
	if err = a.EnableConsolidation(1); err != nil {
		return err
	}
	before := a.Snapshot()
	report, consolidateErr := a.Consolidate(context.Background(), learning.ConsolidationTrigger{Receptor: 0, Threshold: 0, Rate: 1, Retain: 1})
	message := ""
	if consolidateErr != nil {
		message = consolidateErr.Error()
	}
	line, err := json.Marshal(map[string]any{"case": name, "weights": weights, "expected_norm": fmt.Sprintf("%.17g", exactNorm(weights)), "expected_unrepresentable": math.IsInf(exactNorm(weights), 1), "reported_norm": fmt.Sprintf("%.17g", report.BaseL2), "error": message, "applied": report.Applied, "state_changed": !reflect.DeepEqual(before, a.Snapshot()), "used_after": a.Snapshot().Plastic.Slow.Used})
	if err != nil {
		return err
	}
	fmt.Println(string(line))
	return nil
}

func main() {
	for _, tc := range []struct {
		name string
		weights []float64
	}{
		{"upper_finite", []float64{math.MaxFloat64, math.Ldexp(math.MaxFloat64, -27)}},
		{"upper_overflow", []float64{math.MaxFloat64, math.Ldexp(math.MaxFloat64, -26)}},
		{"obvious_overflow", []float64{1.3e308, 1.3e308}},
	} {
		if err := run(tc.name, tc.weights); err != nil {
			panic(err)
		}
	}
}
