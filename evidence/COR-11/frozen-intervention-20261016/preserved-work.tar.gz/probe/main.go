package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/learning"
	"github.com/TimLai666/coimnet/modulation"
	"math"
	"os"
	"reflect"
)

func must(e error) {
	if e != nil {
		panic(e)
	}
}
func individual(neural bool) *learning.Individual {
	c := learning.Config{Dynamics: dynamics.Config{Nodes: 1, DT: math.Ln2, Activation: "tanh"}, InputSize: 1, OutputSize: 1, InputNodes: []int{0}, ReadoutNodes: []int{0}, ReadoutEveryStep: true}
	p := learning.Parameters{Core: dynamics.Parameters{Weights: []float64{}, Bias: []float64{0}, LogTau: []float64{0}}, Encoder: []float64{1}, Readout: []float64{1}}
	a, e := learning.NewIndividual(c, p, learning.DefaultOptions(), []float64{0})
	must(e)
	source := modulation.SourceSpec{Kind: modulation.SourceExternalTimeline, Channel: 0, Timeline: &modulation.ExternalTimeline{ChannelCount: 1}}
	if neural {
		source = modulation.SourceSpec{Kind: modulation.SourceNeuralActivity, Channel: 0, Neural: &modulation.NeuralActivity{Nodes: []int{0}, Gain: 1, Channel: 0}}
	}
	d := modulation.ChemistryConfig{Chemistry: modulation.Chemistry{Regions: 1, Channels: 1, DT: math.Ln2, Tau: []float64{1}}, Sources: []modulation.SourceSpec{source}, Receptors: modulation.Receptors{Records: []modulation.Receptor{{Cells: []int{0}, Signal: "engineering", Channel: 0, Status: modulation.StatusHypothesized, Kd: 1, N: 1, Evidence: "engineering fixture", MeasurementKind: "engineering fixture", MappingVersion: "frozen-intervention/v1"}}}, Effects: []modulation.Effect{{Kind: modulation.EffectSensitivity, Receptor: 0, BetaScale: .5}}, Regions: modulation.RegionAssignment{NodeRegion: []int{0}}}
	must(a.EnableChemistry(d))
	s := a.Snapshot()
	s.Chemical.State.Concentration = [][]float64{{4}}
	a, e = learning.RestoreIndividual(s)
	must(e)
	must(a.FreezeChemistry(true))
	return a
}
func main() {
	if len(os.Args) == 2 && os.Args[1] == "--help" {
		fmt.Println("Usage: probe [--help]\nRuns two public API frozen/no-op intervention witnesses. Prints observed JSON and exits 1 if invariants fail.")
		return
	}
	mustRun := true
	ctx := context.Background()
	input := [][]float64{{1}}
	plan := learning.InterventionPlan{Authorized: true, Reason: "engineering no-op control", Items: []learning.Intervention{{Kind: learning.InterventionBlockChannel, Channel: 0, Start: 10, End: 11, Restore: true}}}
	for _, neural := range []bool{false, true} {
		a := individual(neural)
		before := a.Snapshot()
		control, e := learning.RestoreIndividual(before)
		must(e)
		must(control.FreezeChemistry(true))
		want, e := control.Advance(ctx, input)
		must(e)
		got, log, err := a.Intervene(ctx, plan, input)
		entry := learning.InterventionLogEntry{}
		if len(log.Entries) > 0 {
			entry = log.Entries[0]
		}
		pass := err == nil && reflect.DeepEqual(got, want) && reflect.DeepEqual(a.Snapshot(), control.Snapshot()) && len(log.Entries) == 1 && entry.AppliedRows == 0 && entry.ActivityDelta == 0 && entry.ConcentrationDelta == 0 && entry.PlasticDelta == 0
		message := ""
		if err != nil {
			message = err.Error()
		}
		b, e := json.Marshal(map[string]any{"neural_source": neural, "passed": pass, "error": message, "output": got, "control": want, "activity_delta": entry.ActivityDelta, "concentration_delta": entry.ConcentrationDelta, "applied_rows": entry.AppliedRows, "state_changed_on_error": err != nil && !reflect.DeepEqual(a.Snapshot(), before), "actual_chemical_steps": a.Snapshot().Chemical.State.Steps, "actual_neural_steps": a.Snapshot().Neural.Continuous.Steps})
		must(e)
		fmt.Println(string(b))
		mustRun = mustRun && pass
	}
	if !mustRun {
		os.Exit(1)
	}
}
