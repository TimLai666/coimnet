package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"math/big"
	"os"

	"github.com/TimLai666/coimnet/dynamics"
)

type sequence struct{ shift float64 }

func (s sequence) Forward(context.Context, int, []float64) (*dynamics.Modulation, error) {
	return &dynamics.Modulation{Threshold: [][]float64{{s.shift}}}, nil
}
func (s sequence) NewReverse(context.Context, int, int) (dynamics.ModulationReverse, error) {
	return s, nil
}
func (sequence) BackwardStep(context.Context, int, dynamics.ModulationGradient) ([]dynamics.ActivityGradient, error) {
	return nil, nil
}

func main() {
	ctx := context.Background()
	low := -math.Ldexp(1, 1023)
	base, shift := low/2, -math.MaxFloat64
	sum := new(big.Rat).Add(new(big.Rat).SetFloat64(base), new(big.Rat).SetFloat64(shift))
	floor := new(big.Rat).SetFloat64(low)
	if sum.Cmp(floor) >= 0 {
		panic("fixture does not require projection")
	}
	m, err := dynamics.NewLIF(dynamics.LIFConfig{
		Nodes: 1, DT: math.Ln2, TauSyn: 1, ThetaMin: low, ThetaMax: 0,
		VReset: -math.MaxFloat64, Surrogate: dynamics.LIFSurrogate{Kind: "fast_sigmoid", Scale: 2},
	})
	if err != nil {
		panic(err)
	}
	p := dynamics.LIFParameters{Bias: []float64{0}, LogTau: []float64{0}, ThetaRaw: []float64{0}}
	state, err := m.NewState([]float64{low})
	if err != nil {
		panic(err)
	}
	_, ordinary, _, ordinaryErr := m.AdvanceModulated(ctx, p, state, [][]float64{{low}}, &dynamics.Modulation{Threshold: [][]float64{{shift}}})
	tr, coupledErr := m.ForwardCoupled(ctx, p, []float64{low}, [][]float64{{low}}, sequence{shift: shift})
	var coupled [][]float64
	if tr != nil {
		coupled = tr.Outputs()
	}
	result := map[string]any{
		"inputs_finite": true, "base": base, "shift": shift, "floor": low,
		"float64_sum": fmt.Sprint(base + shift), "exact_sum": sum.RatString(),
		"exact_sum_below_floor": true, "exact_projected_threshold": floor.RatString(),
		"ordinary_error": fmt.Sprint(ordinaryErr), "ordinary_output": ordinary,
		"coupled_error": fmt.Sprint(coupledErr), "coupled_output": coupled,
	}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		panic(err)
	}
}
