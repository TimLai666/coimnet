package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	"github.com/TimLai666/coimnet/learning"
	"github.com/TimLai666/coimnet/modulation"
)

func runClampMatrix(ctx context.Context) ([]matrixRecord, error) {
	records := make([]matrixRecord, 0, 336)
	for _, core := range []string{"continuous", "lif"} {
		for _, profile := range profiles(core) {
			for _, mix := range []string{modulation.MixSum, modulation.MixMax} {
				for _, filled := range []int{1, 3} {
					for _, window := range []int{0, 3} {
						for _, segment := range []int{1, 5, 11} {
							key := caseKey{Core: core, Mix: mix, Profile: profile, Filled: filled, Delay: 5, Window: window, Segment: segment}
							record, err := auditMatrixCase(ctx, key)
							if err != nil {
								return nil, fmt.Errorf("matrix %+v: %w", key, err)
							}
							records = append(records, record)
						}
					}
				}
			}
		}
	}
	return records, nil
}

func runProfileControls(ctx context.Context) ([]profileControl, error) {
	controls := make([]profileControl, 0, 36)
	for _, core := range []string{"continuous", "lif"} {
		for _, profile := range profiles(core) {
			for _, filled := range []int{1, 3} {
				left := caseKey{Core: core, Mix: modulation.MixSum, Profile: profile, Filled: filled, Delay: 5, Window: 0, Segment: 1}
				right := left
				right.Mix = modulation.MixMax
				control, err := auditProfileControl(ctx, left, right, "sum-vs-max")
				if err != nil {
					return nil, err
				}
				controls = append(controls, control)
			}
		}
	}
	for _, core := range []string{"continuous", "lif"} {
		for _, mix := range []string{modulation.MixSum, modulation.MixMax} {
			for _, filled := range []int{1, 3} {
				left := caseKey{Core: core, Mix: mix, Profile: "open-positive", Filled: filled, Delay: 5, Window: 0, Segment: 1}
				right := left
				right.Profile = "open-negative"
				control, err := auditProfileControl(ctx, left, right, "open-positive-vs-open-negative")
				if err != nil {
					return nil, err
				}
				controls = append(controls, control)
			}
		}
	}
	return controls, nil
}

func auditProfileControl(ctx context.Context, leftKey, rightKey caseKey, kind string) (profileControl, error) {
	left, err := auditFixture(leftKey)
	if err != nil {
		return profileControl{}, fmt.Errorf("%s left fixture: %w", kind, err)
	}
	right, err := auditFixture(rightKey)
	if err != nil {
		return profileControl{}, fmt.Errorf("%s right fixture: %w", kind, err)
	}
	leftNetwork, err := learning.NewNetwork(left.Config)
	if err != nil {
		return profileControl{}, fmt.Errorf("%s left network: %w", kind, err)
	}
	rightNetwork, err := learning.NewNetwork(right.Config)
	if err != nil {
		return profileControl{}, fmt.Errorf("%s right network: %w", kind, err)
	}
	leftOutput, err := leftNetwork.PredictAll(ctx, auditCloneParameters(left.Parameters), auditCloneRows(left.Input))
	if err != nil {
		return profileControl{}, fmt.Errorf("%s left output: %w", kind, err)
	}
	rightOutput, err := rightNetwork.PredictAll(ctx, auditCloneParameters(right.Parameters), auditCloneRows(right.Input))
	if err != nil {
		return profileControl{}, fmt.Errorf("%s right output: %w", kind, err)
	}
	if err := auditRowsFinite(leftOutput); err != nil {
		return profileControl{}, fmt.Errorf("%s left output finite: %w", kind, err)
	}
	if err := auditRowsFinite(rightOutput); err != nil {
		return profileControl{}, fmt.Errorf("%s right output finite: %w", kind, err)
	}
	leftGradient, err := leftNetwork.LossGradientFrom(ctx, auditCloneParameters(left.Parameters), auditCloneRows(left.Input), auditCloneRows(left.Upstream), leftKey.Window)
	if err != nil {
		return profileControl{}, fmt.Errorf("%s left gradient: %w", kind, err)
	}
	rightGradient, err := rightNetwork.LossGradientFrom(ctx, auditCloneParameters(right.Parameters), auditCloneRows(right.Input), auditCloneRows(right.Upstream), rightKey.Window)
	if err != nil {
		return profileControl{}, fmt.Errorf("%s right gradient: %w", kind, err)
	}
	if err := auditGradientFinite(leftGradient); err != nil {
		return profileControl{}, fmt.Errorf("%s left gradient finite: %w", kind, err)
	}
	if err := auditGradientFinite(rightGradient); err != nil {
		return profileControl{}, fmt.Errorf("%s right gradient finite: %w", kind, err)
	}
	return profileControl{
		Key:             leftKey,
		Kind:            kind,
		OutputsDiffer:   equal(leftOutput, rightOutput) != nil,
		GradientsDiffer: equal(leftGradient, rightGradient) != nil,
	}, nil
}

func runInitialProofs(ctx context.Context) ([]initialProof, error) {
	proofs := make([]initialProof, 0, 56)
	for _, core := range []string{"continuous", "lif"} {
		for _, profile := range profiles(core) {
			for _, mix := range []string{modulation.MixSum, modulation.MixMax} {
				for _, filled := range []int{1, 3} {
					key := caseKey{Core: core, Mix: mix, Profile: profile, Filled: filled, Delay: 5, Window: 0, Segment: 1}
					proof, err := auditInitialProof(ctx, key)
					if err != nil {
						return nil, fmt.Errorf("initial proof %+v: %w", key, err)
					}
					proofs = append(proofs, proof)
				}
			}
		}
	}
	return proofs, nil
}

func auditInitialProof(ctx context.Context, key caseKey) (initialProof, error) {
	var zero initialProof
	if err := auditContextError(ctx); err != nil {
		return zero, err
	}
	fx, err := auditFixture(key)
	if err != nil {
		return zero, err
	}
	if fx.Config.Chemistry == nil {
		return zero, fmt.Errorf("fixture has no chemical episode")
	}
	episode := fx.Config.Chemistry
	declaration := episode.Part.Config
	sources := make([]modulation.Source, len(declaration.Sources))
	for index, spec := range declaration.Sources {
		sources[index], err = spec.Build()
		if err != nil {
			return zero, fmt.Errorf("source %d build: %w", index, err)
		}
		if spec.Kind != modulation.SourceController {
			continue
		}
		controller, ok := sources[index].(*modulation.Controller)
		if !ok || controller == nil {
			return zero, fmt.Errorf("source %d did not build a controller", index)
		}
		if index >= len(episode.Part.SourceStates) || episode.Part.SourceStates[index].Controller == nil {
			return zero, fmt.Errorf("source %d has no controller state", index)
		}
		if err := controller.RestoreState(*episode.Part.SourceStates[index].Controller); err != nil {
			return zero, fmt.Errorf("source %d restore state: %w", index, err)
		}
	}
	resources := make(map[string]float64, len(episode.Part.Resources))
	for name, amount := range episode.Part.Resources {
		resources[name] = amount
	}
	sourceContext := modulation.SourceContext{
		Activity:  append([]float64(nil), episode.InitialActivity...),
		Resources: resources,
		// The fixture's pending feedback becomes available at step 9, while
		// this proof releases the first row at source step 7.
		Feedback: nil,
	}
	release := make([]float64, len(declaration.Sources))
	for index, source := range sources {
		rates, err := source.Release(episode.SourceStep, sourceContext)
		if err != nil {
			return zero, fmt.Errorf("source %d release: %w", index, err)
		}
		if len(rates) != index+1 {
			return zero, fmt.Errorf("source %d release width %d, want %d", index, len(rates), index+1)
		}
		for channel, rate := range rates {
			if !auditFiniteFloat(rate) || rate < 0 {
				return zero, fmt.Errorf("source %d rate[%d]=%g is invalid", index, channel, rate)
			}
			if channel != index && rate != 0 {
				return zero, fmt.Errorf("source %d released channel %d=%g", index, channel, rate)
			}
		}
		release[index] = rates[index]
	}
	releaseGrid := make([][]float64, declaration.Chemistry.Regions)
	for region := range releaseGrid {
		releaseGrid[region] = append([]float64(nil), release...)
	}
	kinetics, err := modulation.NewChemistry(declaration.Chemistry)
	if err != nil {
		return zero, fmt.Errorf("chemistry: %w", err)
	}
	state := episode.Part.State
	state.Concentration = auditCloneRows(state.Concentration)
	next, err := kinetics.Step(state, releaseGrid, nil)
	if err != nil {
		return zero, fmt.Errorf("chemistry step: %w", err)
	}
	occupancies, _, err := declaration.Receptors.Occupancies(next, declaration.Regions.NodeRegion)
	if err != nil {
		return zero, fmt.Errorf("occupancies: %w", err)
	}
	gain, offset, threshold, clamped, err := modulation.ApplyEffects(declaration.Effects, occupancies, key.Mix, len(declaration.Regions.NodeRegion))
	if err != nil {
		return zero, fmt.Errorf("effects: %w", err)
	}
	return initialProof{
		Key:           key,
		Clamp:         clamped,
		Release:       release,
		Concentration: next.Concentration,
		Occupancies:   occupancies,
		Gain:          gain,
		Offset:        offset,
		Threshold:     threshold,
	}, nil
}

func runClampReferences(ctx context.Context) ([]clampReference, error) {
	references := make([]clampReference, 0, 432)
	for _, profile := range commonProfiles {
		for _, mix := range []string{modulation.MixSum, modulation.MixMax} {
			for _, filled := range []int{1, 3} {
				key := caseKey{Core: "continuous", Mix: mix, Profile: profile, Filled: filled, Delay: 5, Window: 0, Segment: 1}
				fx, err := auditFixture(key)
				if err != nil {
					return nil, fmt.Errorf("reference fixture %+v: %w", key, err)
				}
				network, err := learning.NewNetwork(fx.Config)
				if err != nil {
					return nil, fmt.Errorf("reference network %+v: %w", key, err)
				}
				gradient, err := network.LossGradientFrom(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), auditCloneRows(fx.Upstream), key.Window)
				if err != nil {
					return nil, fmt.Errorf("reference gradient %+v: %w", key, err)
				}
				if err := auditGradientFinite(gradient); err != nil {
					return nil, fmt.Errorf("reference gradient finite %+v: %w", key, err)
				}
				flat := auditFlatGradient(gradient)
				for coordinateIndex, coordinate := range auditParameterCoordinates(fx.Parameters) {
					plus := auditCloneParameters(fx.Parameters)
					minus := auditCloneParameters(fx.Parameters)
					coordinate.set(&plus, referenceEpsilon)
					coordinate.set(&minus, -referenceEpsilon)
					plusObjective, err := auditObjective(ctx, network, plus, fx.Input, fx.Upstream)
					if err != nil {
						return nil, fmt.Errorf("reference plus %+v %s: %w", key, coordinate.name, err)
					}
					minusObjective, err := auditObjective(ctx, network, minus, fx.Input, fx.Upstream)
					if err != nil {
						return nil, fmt.Errorf("reference minus %+v %s: %w", key, coordinate.name, err)
					}
					if coordinateIndex >= len(flat) {
						return nil, fmt.Errorf("reference parameter gradient index %d outside %d", coordinateIndex, len(flat))
					}
					references = append(references, clampReference{Key: key, Coordinate: coordinate.name, Gradient: flat[coordinateIndex], Reference: (plusObjective - minusObjective) / (2 * referenceEpsilon)})
				}
				for row := range fx.Input {
					if len(fx.Input[row]) != 1 || row >= len(gradient.Inputs) || len(gradient.Inputs[row]) != 1 {
						return nil, fmt.Errorf("reference input shape row %d for %+v", row, key)
					}
					plus := auditCloneRows(fx.Input)
					minus := auditCloneRows(fx.Input)
					plus[row][0] += referenceEpsilon
					minus[row][0] -= referenceEpsilon
					plusObjective, err := auditObjective(ctx, network, fx.Parameters, plus, fx.Upstream)
					if err != nil {
						return nil, fmt.Errorf("reference input plus %+v row%d: %w", key, row, err)
					}
					minusObjective, err := auditObjective(ctx, network, fx.Parameters, minus, fx.Upstream)
					if err != nil {
						return nil, fmt.Errorf("reference input minus %+v row%d: %w", key, row, err)
					}
					references = append(references, clampReference{Key: key, Coordinate: fmt.Sprintf("input[%d]", row), Gradient: gradient.Inputs[row][0], Reference: (plusObjective - minusObjective) / (2 * referenceEpsilon)})
				}
			}
		}
	}
	return references, nil
}

func writeClampResumeCases(ctx context.Context, newDir string) ([]string, error) {
	if err := auditContextError(ctx); err != nil {
		return nil, err
	}
	info, err := os.Stat(newDir)
	if err != nil {
		return nil, fmt.Errorf("resume directory: %w", err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("resume path %s is not a directory", newDir)
	}
	paths := make([]string, 0, 28)
	for _, core := range []string{"continuous", "lif"} {
		resumeProfiles := []string{"open-negative", "gain-lower", "offset-upper"}
		if core == "lif" {
			resumeProfiles = append(resumeProfiles, "threshold-lower")
		}
		for _, profile := range resumeProfiles {
			for _, filled := range []int{1, 3} {
				for _, segment := range []int{1, 5} {
					key := caseKey{Core: core, Mix: modulation.MixMax, Profile: profile, Filled: filled, Delay: 5, Window: 3, Segment: segment}
					path, err := auditOneClampResume(ctx, newDir, key)
					if err != nil {
						return nil, err
					}
					paths = append(paths, path)
				}
			}
		}
	}
	return paths, nil
}

func auditOneClampResume(ctx context.Context, newDir string, key caseKey) (string, error) {
	fx, err := auditFixture(key)
	if err != nil {
		return "", fmt.Errorf("resume fixture %+v: %w", key, err)
	}
	full, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, false))
	if err != nil {
		return "", fmt.Errorf("resume full trainer %+v: %w", key, err)
	}
	defer func() { _ = full.Close() }()
	recompute, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, true))
	if err != nil {
		return "", fmt.Errorf("resume recompute trainer %+v: %w", key, err)
	}
	defer func() { _ = recompute.Close() }()
	fullFirst, err := full.StepFrom(ctx, auditCloneRows(fx.Input), auditCloneRows(fx.Upstream))
	if err != nil {
		return "", fmt.Errorf("resume full first %+v: %w", key, err)
	}
	recomputeFirst, err := recompute.StepFrom(ctx, auditCloneRows(fx.Input), auditCloneRows(fx.Upstream))
	if err != nil {
		return "", fmt.Errorf("resume recompute first %+v: %w", key, err)
	}
	if err := auditResultFinite(fullFirst); err != nil {
		return "", fmt.Errorf("resume full first finite %+v: %w", key, err)
	}
	if err := auditResultFinite(recomputeFirst); err != nil {
		return "", fmt.Errorf("resume recompute first finite %+v: %w", key, err)
	}
	if err := equal(fullFirst, recomputeFirst); err != nil {
		return "", fmt.Errorf("resume first result %+v: %w", key, err)
	}
	fullSnapshot := full.Snapshot()
	recomputeSnapshot := recompute.Snapshot()
	if fullSnapshot.Accumulator == nil || fullSnapshot.Accumulator.Count != 1 || recomputeSnapshot.Accumulator == nil || recomputeSnapshot.Accumulator.Count != 1 {
		return "", fmt.Errorf("resume first accumulator %+v", key)
	}
	if err := equal(normalized(fullSnapshot), normalized(recomputeSnapshot)); err != nil {
		return "", fmt.Errorf("resume first snapshot %+v: %w", key, err)
	}
	operations := []string{"step", "from", "step", "from"}
	expected, err := continueTrainer(ctx, full, key, operations)
	if err != nil {
		return "", fmt.Errorf("resume expected %+v: %w", key, err)
	}
	path := filepath.Join(newDir, fmt.Sprintf("resume-%s-%s-%s-filled%d-delay%d-window%d-segment%d.json", key.Core, key.Mix, key.Profile, key.Filled, key.Delay, key.Window, key.Segment))
	input := resumeInput{Key: key, Snapshot: recomputeSnapshot, Operations: append([]string(nil), operations...), Expected: expected}
	if err := auditWriteJSON(path, input); err != nil {
		return "", fmt.Errorf("resume write %+v: %w", key, err)
	}
	return path, nil
}
