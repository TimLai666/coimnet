package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"reflect"
	"sort"

	"github.com/TimLai666/coimnet/learning"
)

type caseKey struct {
	Core, Mix, Profile             string
	Filled, Delay, Window, Segment int
}
type fixture struct {
	Config          learning.Config
	Parameters      learning.Parameters
	Input, Upstream [][]float64
	Target          []float64
}
type trace struct {
	Result      learning.StepResult
	Snapshot    learning.TrainingSnapshot
	Predictions [][]float64
}
type resumeInput struct {
	Key        caseKey
	Snapshot   learning.TrainingSnapshot
	Operations []string
	Expected   []trace
}
type matrixRecord struct {
	Key                                                        caseKey
	Operations                                                 int
	PredictionSHA256, FirstGradientSHA256, FinalSnapshotSHA256 string
	ParametersChanged                                          bool
	FirstUpdateMeanNorm                                        float64
	FirstUpdateClipped                                         bool
}

func hash(v any) string {
	b, err := json.Marshal(v)
	if err != nil {
		panic(err)
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}
func normalized(s learning.TrainingSnapshot) learning.TrainingSnapshot {
	s.Options.Recompute = nil
	return s
}

// Exact scalar comparisons preserve the sign of zero. All public fields and
// the zero-valued private fields in declaration structs remain in the walk.
func equal(a, b any) error { return compare(reflect.ValueOf(a), reflect.ValueOf(b), "root") }
func compare(a, b reflect.Value, path string) error {
	if !a.IsValid() || !b.IsValid() {
		if a.IsValid() == b.IsValid() {
			return nil
		}
		return fmt.Errorf("%s validity", path)
	}
	if a.Type() != b.Type() {
		return fmt.Errorf("%s type", path)
	}
	fail := func() error { return fmt.Errorf("%s differs", path) }
	switch a.Kind() {
	case reflect.Pointer, reflect.Interface:
		if a.IsNil() != b.IsNil() {
			return fail()
		}
		if a.IsNil() {
			return nil
		}
		return compare(a.Elem(), b.Elem(), path+"*")
	case reflect.Slice:
		if a.IsNil() != b.IsNil() {
			return fail()
		}
		fallthrough
	case reflect.Array:
		if a.Len() != b.Len() {
			return fail()
		}
		for i := 0; i < a.Len(); i++ {
			if err := compare(a.Index(i), b.Index(i), fmt.Sprintf("%s[%d]", path, i)); err != nil {
				return err
			}
		}
	case reflect.Struct:
		for i := 0; i < a.NumField(); i++ {
			if err := compare(a.Field(i), b.Field(i), path+"."+a.Type().Field(i).Name); err != nil {
				return err
			}
		}
	case reflect.Map:
		if a.IsNil() != b.IsNil() || a.Len() != b.Len() {
			return fail()
		}
		keys := a.MapKeys()
		sort.Slice(keys, func(i, j int) bool { return keys[i].String() < keys[j].String() })
		for _, k := range keys {
			if err := compare(a.MapIndex(k), b.MapIndex(k), path+"["+k.String()+"]"); err != nil {
				return err
			}
		}
	case reflect.Float64:
		if math.Float64bits(a.Float()) != math.Float64bits(b.Float()) {
			return fail()
		}
	case reflect.Float32:
		if math.Float32bits(float32(a.Float())) != math.Float32bits(float32(b.Float())) {
			return fail()
		}
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		if a.Int() != b.Int() {
			return fail()
		}
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		if a.Uint() != b.Uint() {
			return fail()
		}
	case reflect.Bool:
		if a.Bool() != b.Bool() {
			return fail()
		}
	case reflect.String:
		if a.String() != b.String() {
			return fail()
		}
	default:
		return fmt.Errorf("unsupported comparison kind %s at %s", a.Kind(), path)
	}
	return nil
}
func main() {
	if err := run(context.Background()); err != nil {
		_ = json.NewEncoder(os.Stdout).Encode(map[string]any{"error": err.Error()})
		os.Exit(2)
	}
}
func run(ctx context.Context) error {
	if len(os.Args) != 3 {
		return fmt.Errorf("usage: probe audit NEW_RESUME_DIR | probe resume SNAPSHOT_JSON")
	}
	if os.Args[1] == "resume" {
		b, err := os.ReadFile(os.Args[2])
		if err != nil {
			return err
		}
		var input resumeInput
		if err = json.Unmarshal(b, &input); err != nil {
			return err
		}
		before := hash(input)
		tr, err := learning.RestoreTrainer(input.Snapshot)
		if err != nil {
			return err
		}
		defer tr.Close()
		actual, err := continueTrainer(ctx, tr, input.Key, input.Operations)
		if err != nil {
			return err
		}
		if err = equal(actual, input.Expected); err != nil {
			return fmt.Errorf("resume %+v: %w", input.Key, err)
		}
		if hash(input) != before {
			return fmt.Errorf("resume mutated caller snapshot")
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"all_passed": true, "mode": "resume", "key": input.Key, "operations": len(actual), "trace_sha256": hash(actual)})
	}
	if os.Args[1] != "audit" {
		return fmt.Errorf("unknown mode %q", os.Args[1])
	}
	matrix, err := runClampMatrix(ctx)
	if err != nil {
		return err
	}
	if len(matrix) != 336 {
		return fmt.Errorf("matrix count %d want336", len(matrix))
	}
	controls, err := runProfileControls(ctx)
	if err != nil {
		return err
	}
	if len(controls) != 36 {
		return fmt.Errorf("controls %d want36", len(controls))
	}
	for _, c := range controls {
		if !c.OutputsDiffer && !c.GradientsDiffer {
			return fmt.Errorf("inactive control %+v", c)
		}
	}
	proofs, err := runInitialProofs(ctx)
	if err != nil {
		return err
	}
	if len(proofs) != 56 {
		return fmt.Errorf("initial proofs %d want56", len(proofs))
	}
	for _, p := range proofs {
		if err := checkInitialProof(p); err != nil {
			return err
		}
	}
	references, err := runClampReferences(ctx)
	if err != nil {
		return err
	}
	if len(references) != 432 {
		return fmt.Errorf("references %d want432", len(references))
	}
	nonzero := map[string]int{}
	groups := map[string]bool{}
	for _, r := range references {
		tol := .002 + .002*math.Abs(r.Reference)
		if !auditFiniteFloat(r.Gradient) || !auditFiniteFloat(r.Reference) || math.Abs(r.Gradient-r.Reference) > tol {
			return fmt.Errorf("reference %+v error exceeds %g", r, tol)
		}
		key := fmt.Sprintf("%s/%s/%d", r.Key.Mix, r.Key.Profile, r.Key.Filled)
		groups[key] = true
		if math.Abs(r.Reference) > tol {
			nonzero[key]++
		}
	}
	if len(groups) != 24 || len(nonzero) != 24 {
		return fmt.Errorf("reference groups %d nonzero groups %d want24", len(groups), len(nonzero))
	}
	resumes, err := writeClampResumeCases(ctx, os.Args[2])
	if err != nil {
		return err
	}
	if len(resumes) != 28 {
		return fmt.Errorf("resumes %d want28", len(resumes))
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"all_passed": true, "mode": "audit", "matrix": matrix, "controls": controls, "initial_proofs": proofs, "references": references, "resume_inputs": resumes})
}
