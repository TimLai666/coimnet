package main

import (
	"fmt"
	"github.com/TimLai666/coimnet/modulation"
)

const referenceEpsilon = .002

var commonProfiles = []string{"open-positive", "open-negative", "gain-upper", "gain-lower", "offset-upper", "offset-lower"}

func profiles(core string) []string {
	v := append([]string(nil), commonProfiles...)
	if core == "lif" {
		v = append(v, "threshold-upper", "threshold-lower")
	}
	return v
}

type coefficients struct{ GS, BS, GMin, GMax, BMax, TS, TMax float64 }

func profileCoefficients(name string) (coefficients, error) {
	s := coefficients{GS: .05, BS: .02, GMin: .5, GMax: 2, BMax: 1, TS: .1, TMax: .8}
	switch name {
	case "open-positive":
	case "open-negative":
		s.GS = -.05
		s.BS = -.02
		s.TS = -.1
	case "gain-upper":
		s.GS = 1
		s.GMin = .75
		s.GMax = 1.005
	case "gain-lower":
		s.GS = -1
		s.GMin = .995
		s.GMax = 1.25
		s.BS = -.02
		s.TS = -.1
	case "offset-upper":
		s.BS = .1
		s.BMax = .0005
	case "offset-lower":
		s.GS = -.05
		s.BS = -.1
		s.BMax = .0005
		s.TS = -.1
	case "threshold-upper":
		s.TMax = .0005
	case "threshold-lower":
		s.GS = -.05
		s.BS = -.02
		s.TS = -.1
		s.TMax = .0005
	default:
		return s, fmt.Errorf("unknown profile %q", name)
	}
	return s, nil
}
func auditFixture(key caseKey) (fixture, error) {
	f, err := baseFixture(key)
	if err != nil {
		return fixture{}, err
	}
	s, err := profileCoefficients(key.Profile)
	if err != nil {
		return fixture{}, err
	}
	if key.Mix != modulation.MixSum && key.Mix != modulation.MixMax {
		return fixture{}, fmt.Errorf("unknown mix %q", key.Mix)
	}
	if key.Core != "lif" && (key.Profile == "threshold-upper" || key.Profile == "threshold-lower") {
		return fixture{}, fmt.Errorf("threshold requires lif")
	}
	c := &f.Config.Chemistry.Part.Config
	c.Receptors.Mix = key.Mix
	if key.Core == "lif" {
		c.Effects = append(c.Effects, modulation.Effect{Kind: modulation.EffectThreshold, Receptor: 2})
	}
	for i := range c.Effects {
		v := &c.Effects[i]
		if v.Kind == modulation.EffectSensitivity {
			v.GammaScale = s.GS
			v.BetaScale = s.BS
			v.GammaMin = s.GMin
			v.GammaMax = s.GMax
			v.BetaAbsMax = s.BMax
		} else {
			v.ThetaScale = s.TS
			v.ThetaAbsMax = s.TMax
		}
	}
	return f, nil
}

type profileControl struct {
	Key                            caseKey
	Kind                           string
	OutputsDiffer, GradientsDiffer bool
}
type clampReference struct {
	Key                 caseKey
	Coordinate          string
	Gradient, Reference float64
}
type initialProof struct {
	Key                     caseKey
	Clamp                   modulation.ClampReport
	Release                 []float64
	Concentration           [][]float64
	Occupancies             []modulation.OccupancyRecord
	Gain, Offset, Threshold []float64
}

func checkInitialProof(p initialProof) error {
	if err := auditRowsFinite([][]float64{p.Release, p.Gain, p.Offset, p.Threshold}); err != nil {
		return err
	}
	if len(p.Concentration) != 2 || len(p.Occupancies) != 7 {
		return fmt.Errorf("initial state/occupancy proof shape")
	}
	for _, row := range p.Concentration {
		if len(row) != 5 {
			return fmt.Errorf("initial concentration width")
		}
	}
	if err := auditRowsFinite(p.Concentration); err != nil {
		return err
	}
	if len(p.Release) != 5 || len(p.Gain) != 2 || len(p.Offset) != 2 || len(p.Threshold) != 2 {
		return fmt.Errorf("initial proof shape %+v", p.Key)
	}
	if p.Release[0] <= 0 || p.Release[1] != 0 || mathAbs(p.Release[2]-.06) > 1e-14 || mathAbs(p.Release[3]-.36) > 1e-14 || mathAbs(p.Release[4]-.08) > 1e-14 {
		return fmt.Errorf("initial release %+v %v", p.Key, p.Release)
	}
	s, err := profileCoefficients(p.Key.Profile)
	if err != nil {
		return err
	}
	sensitivity, threshold := [2]float64{}, [2]float64{}
	for _, o := range p.Occupancies {
		if !auditFiniteFloat(o.Occupancy) || o.Occupancy < 0 || o.Occupancy > 1 || o.Receptor < 0 || o.Receptor > 4 || o.Channel != o.Receptor {
			return fmt.Errorf("invalid occupancy proof")
		}
		region := 0
		if o.Receptor == 0 || o.Receptor == 2 {
			region = 1
		}
		if o.Region != region {
			return fmt.Errorf("invalid receptor region proof")
		}
		if o.Cell < 0 || o.Cell >= 2 {
			return fmt.Errorf("invalid proof cell")
		}
		sens := p.Key.Core == "continuous" || o.Receptor != 0
		theta := p.Key.Core == "lif" && (o.Receptor == 0 || o.Receptor == 2)
		for _, target := range []struct {
			yes bool
			v   *[2]float64
		}{{sens, &sensitivity}, {theta, &threshold}} {
			if !target.yes {
				continue
			}
			if p.Key.Mix == modulation.MixSum {
				target.v[o.Cell] += o.Occupancy
			} else if o.Occupancy > target.v[o.Cell] {
				target.v[o.Cell] = o.Occupancy
			}
		}
	}
	for i := 0; i < 2; i++ {
		g := bound(1+s.GS*sensitivity[i], s.GMin, s.GMax)
		b := bound(s.BS*sensitivity[i], -s.BMax, s.BMax)
		t := 0.
		if p.Key.Core == "lif" {
			t = bound(s.TS*threshold[i], -s.TMax, s.TMax)
		}
		if mathAbs(p.Gain[i]-g) > 1e-12 || mathAbs(p.Offset[i]-b) > 1e-12 || mathAbs(p.Threshold[i]-t) > 1e-12 {
			return fmt.Errorf("initial effect oracle %+v node%d", p.Key, i)
		}
	}
	want := modulation.ClampReport{}
	switch p.Key.Profile {
	case "gain-upper", "gain-lower":
		want.Gamma = 2
	case "offset-upper", "offset-lower":
		want.Beta = 2
	case "threshold-upper", "threshold-lower":
		want.Theta = 2
	}
	if p.Clamp != want {
		return fmt.Errorf("first clamp %+v got%+v want%+v", p.Key, p.Clamp, want)
	}
	return nil
}
func bound(v, lo, hi float64) float64 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
func mathAbs(v float64) float64 {
	if v < 0 {
		return -v
	}
	return v
}
