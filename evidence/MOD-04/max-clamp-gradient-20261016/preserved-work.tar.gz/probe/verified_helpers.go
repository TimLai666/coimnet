package main

import (
	"context"
	"fmt"
	"github.com/TimLai666/coimnet/learning"
	"math"
)

var auditOperations = []string{"from", "step", "from", "step", "from"}

type auditParameterCoordinate struct {
	name string
	set  func(*learning.Parameters, float64)
}

func auditMatrixCase(ctx context.Context, key caseKey) (matrixRecord, error) {
	var zero matrixRecord
	if err := auditContextError(ctx); err != nil {
		return zero, err
	}
	fx, err := auditFixture(key)
	if err != nil {
		return zero, err
	}
	originalConfig, err := auditCloneConfig(fx.Config)
	if err != nil {
		return zero, err
	}
	originalParameters := auditCloneParameters(fx.Parameters)
	originalInput := auditCloneRows(fx.Input)
	originalUpstream := auditCloneRows(fx.Upstream)
	originalTarget := append([]float64(nil), fx.Target...)
	full, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, false))
	if err != nil {
		return zero, fmt.Errorf("full trainer: %w", err)
	}
	recompute, err := learning.NewTrainer(fx.Config, fx.Parameters, auditOptions(key, true))
	if err != nil {
		_ = full.Close()
		return zero, fmt.Errorf("recompute trainer: %w", err)
	}
	defer func() { _ = full.Close() }()
	defer func() { _ = recompute.Close() }()
	network, err := learning.NewNetwork(fx.Config)
	if err != nil {
		return zero, fmt.Errorf("network: %w", err)
	}
	publicGradient, err := network.LossGradientFrom(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), auditCloneRows(fx.Upstream), key.Window)
	if err != nil {
		return zero, fmt.Errorf("public gradient: %w", err)
	}
	if err := auditGradientFinite(publicGradient); err != nil {
		return zero, fmt.Errorf("public gradient finite: %w", err)
	}
	publicAgain, err := network.LossGradientFrom(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), auditCloneRows(fx.Upstream), key.Window)
	if err != nil {
		return zero, fmt.Errorf("repeated public gradient: %w", err)
	}
	if err := equal(publicGradient, publicAgain); err != nil {
		return zero, fmt.Errorf("repeated public gradient differs: %w", err)
	}
	firstGradient := auditFlatGradient(publicGradient)
	if len(firstGradient) == 0 || !auditAnyNonzero(firstGradient) {
		return zero, fmt.Errorf("public parameter gradient is zero")
	}
	_, mseGradient, err := network.LossGradient(ctx, auditCloneParameters(fx.Parameters), auditCloneRows(fx.Input), append([]float64(nil), fx.Target...), key.Window)
	if err != nil {
		return zero, fmt.Errorf("public MSE gradient: %w", err)
	}
	if err := auditGradientFinite(mseGradient); err != nil {
		return zero, fmt.Errorf("public MSE gradient finite: %w", err)
	}
	mseFlat := auditFlatGradient(mseGradient)
	if len(mseFlat) != len(firstGradient) {
		return zero, fmt.Errorf("public MSE gradient length %d, upstream gradient length %d", len(mseFlat), len(firstGradient))
	}
	firstUpdateMeanNorm := 0.0
	for index := range firstGradient {
		mean := (firstGradient[index] + mseFlat[index]) / 2
		if !auditFiniteFloat(mean) {
			return zero, fmt.Errorf("first update mean gradient[%d] is non-finite: %g", index, mean)
		}
		firstUpdateMeanNorm = math.Hypot(firstUpdateMeanNorm, mean)
		if !auditFiniteFloat(firstUpdateMeanNorm) {
			return zero, fmt.Errorf("first update mean norm is non-finite after gradient[%d]", index)
		}
	}
	firstUpdateClipped := firstUpdateMeanNorm > auditOptions(key, false).ClipNorm
	initial := full.Snapshot()
	for index, operation := range auditOperations {
		fullPrediction, err := full.PredictAll(ctx, auditCloneRows(fx.Input))
		if err != nil {
			return zero, fmt.Errorf("full prediction before %s: %w", operation, err)
		}
		recomputePrediction, err := recompute.PredictAll(ctx, auditCloneRows(fx.Input))
		if err != nil {
			return zero, fmt.Errorf("recompute prediction before %s: %w", operation, err)
		}
		if err := equal(fullPrediction, recomputePrediction); err != nil {
			return zero, fmt.Errorf("prediction before operation %d: %w", index, err)
		}
		fullResult, fullInput, fullTarget, fullUpstream, err := auditTrainerOperation(ctx, full, operation, fx)
		if err != nil {
			return zero, fmt.Errorf("full %s: %w", operation, err)
		}
		recomputeResult, recomputeInput, recomputeTarget, recomputeUpstream, err := auditTrainerOperation(ctx, recompute, operation, fx)
		if err != nil {
			return zero, fmt.Errorf("recompute %s: %w", operation, err)
		}
		if err := auditResultFinite(fullResult); err != nil {
			return zero, fmt.Errorf("full result %s finite: %w", operation, err)
		}
		if err := auditResultFinite(recomputeResult); err != nil {
			return zero, fmt.Errorf("recompute result %s finite: %w", operation, err)
		}
		if err := equal(fullResult, recomputeResult); err != nil {
			return zero, fmt.Errorf("StepResult operation %d: %w", index, err)
		}
		if err := equal(normalized(full.Snapshot()), normalized(recompute.Snapshot())); err != nil {
			return zero, fmt.Errorf("snapshot operation %d: %w", index, err)
		}
		if err := equal(fullInput, fx.Input); err != nil {
			return zero, fmt.Errorf("full %s mutated input: %w", operation, err)
		}
		if err := equal(recomputeInput, fx.Input); err != nil {
			return zero, fmt.Errorf("recompute %s mutated input: %w", operation, err)
		}
		if err := equal(fullTarget, fx.Target); err != nil {
			return zero, fmt.Errorf("full %s mutated target: %w", operation, err)
		}
		if err := equal(recomputeTarget, fx.Target); err != nil {
			return zero, fmt.Errorf("recompute %s mutated target: %w", operation, err)
		}
		if err := equal(fullUpstream, fx.Upstream); err != nil {
			return zero, fmt.Errorf("full %s mutated upstream: %w", operation, err)
		}
		if err := equal(recomputeUpstream, fx.Upstream); err != nil {
			return zero, fmt.Errorf("recompute %s mutated upstream: %w", operation, err)
		}
		if index == 0 {
			for name, snapshot := range map[string]learning.TrainingSnapshot{"full": full.Snapshot(), "recompute": recompute.Snapshot()} {
				if snapshot.Accumulator == nil || snapshot.Accumulator.Count != 1 {
					return zero, fmt.Errorf("%s first pending snapshot has accumulator %+v", name, snapshot.Accumulator)
				}
				if len(snapshot.Accumulator.Sum) != len(firstGradient) {
					return zero, fmt.Errorf("%s first pending gradient length %d, want %d", name, len(snapshot.Accumulator.Sum), len(firstGradient))
				}
				for gradientIndex := range firstGradient {
					if snapshot.Accumulator.Sum[gradientIndex] != firstGradient[gradientIndex] {
						return zero, fmt.Errorf("%s first pending gradient[%d]=%g, want %g", name, gradientIndex, snapshot.Accumulator.Sum[gradientIndex], firstGradient[gradientIndex])
					}
				}
			}
		}
	}
	finalSnapshot := full.Snapshot()
	if err := equal(normalized(finalSnapshot), normalized(recompute.Snapshot())); err != nil {
		return zero, fmt.Errorf("final snapshot: %w", err)
	}
	if finalSnapshot.Updates != 2 {
		return zero, fmt.Errorf("final snapshot updates=%d, want 2", finalSnapshot.Updates)
	}
	if finalSnapshot.Accumulator == nil || finalSnapshot.Accumulator.Count != 1 {
		return zero, fmt.Errorf("final snapshot has accumulator %+v, want count 1", finalSnapshot.Accumulator)
	}
	if err := equal(initial.Parameters, finalSnapshot.Parameters); err == nil {
		return zero, fmt.Errorf("parameters did not change after two accumulated updates")
	}
	finalPrediction, err := full.PredictAll(ctx, auditCloneRows(fx.Input))
	if err != nil {
		return zero, fmt.Errorf("final prediction: %w", err)
	}
	if err := auditRowsFinite(finalPrediction); err != nil {
		return zero, fmt.Errorf("final prediction finite: %w", err)
	}
	if err := equal(fx.Config, originalConfig); err != nil {
		return zero, fmt.Errorf("caller config changed: %w", err)
	}
	if err := equal(fx.Parameters, originalParameters); err != nil {
		return zero, fmt.Errorf("caller parameters changed: %w", err)
	}
	if err := equal(fx.Input, originalInput); err != nil {
		return zero, fmt.Errorf("caller input changed: %w", err)
	}
	if err := equal(fx.Upstream, originalUpstream); err != nil {
		return zero, fmt.Errorf("caller upstream changed: %w", err)
	}
	if err := equal(fx.Target, originalTarget); err != nil {
		return zero, fmt.Errorf("caller target changed: %w", err)
	}
	return matrixRecord{Key: key, Operations: len(auditOperations), PredictionSHA256: hash(finalPrediction), FirstGradientSHA256: hash(publicGradient), FinalSnapshotSHA256: hash(normalized(finalSnapshot)), ParametersChanged: true, FirstUpdateMeanNorm: firstUpdateMeanNorm, FirstUpdateClipped: firstUpdateClipped}, nil
}

func auditTrainerOperation(ctx context.Context, trainer *learning.Trainer, operation string, fx fixture) (learning.StepResult, [][]float64, []float64, [][]float64, error) {
	input := auditCloneRows(fx.Input)
	target := append([]float64(nil), fx.Target...)
	upstream := auditCloneRows(fx.Upstream)
	var (
		result learning.StepResult
		err    error
	)
	switch operation {
	case "step":
		result, err = trainer.Step(ctx, input, target)
	case "from":
		result, err = trainer.StepFrom(ctx, input, upstream)
	default:
		err = fmt.Errorf("unknown operation %q", operation)
	}
	return result, input, target, upstream, err
}

func auditParameterCoordinates(p learning.Parameters) []auditParameterCoordinate {
	coordinates := make([]auditParameterCoordinate, 0, 10)
	for index := range p.Core.Weights {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("weights[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Core.Weights[i] += delta }})
	}
	for index := range p.Core.Bias {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("bias[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Core.Bias[i] += delta }})
	}
	for index := range p.Core.LogTau {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("log_tau[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Core.LogTau[i] += delta }})
	}
	for index := range p.Encoder {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("encoder[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Encoder[i] += delta }})
	}
	for index := range p.Readout {
		i := index
		coordinates = append(coordinates, auditParameterCoordinate{name: fmt.Sprintf("readout[%d]", i), set: func(q *learning.Parameters, delta float64) { q.Readout[i] += delta }})
	}
	return coordinates
}

func auditObjective(ctx context.Context, network *learning.Network, p learning.Parameters, input, upstream [][]float64) (float64, error) {
	rows, err := network.PredictAll(ctx, auditCloneParameters(p), auditCloneRows(input))
	if err != nil {
		return 0, err
	}
	if len(rows) != len(upstream) {
		return 0, fmt.Errorf("prediction rows=%d upstream rows=%d", len(rows), len(upstream))
	}
	var objective float64
	for row := range rows {
		if len(rows[row]) != len(upstream[row]) {
			return 0, fmt.Errorf("objective row %d width mismatch", row)
		}
		for column := range rows[row] {
			objective += rows[row][column] * upstream[row][column]
		}
	}
	if !auditFiniteFloat(objective) {
		return 0, fmt.Errorf("objective is not finite")
	}
	return objective, nil
}

func continueTrainer(ctx context.Context, trainer *learning.Trainer, key caseKey, operations []string) ([]trace, error) {
	if trainer == nil {
		return nil, fmt.Errorf("nil trainer")
	}
	fx, err := auditFixture(key)
	if err != nil {
		return nil, err
	}
	traces := make([]trace, 0, len(operations))
	for index, operation := range operations {
		if err := auditContextError(ctx); err != nil {
			return nil, err
		}
		input := auditCloneRows(fx.Input)
		upstream := auditCloneRows(fx.Upstream)
		target := append([]float64(nil), fx.Target...)
		var result learning.StepResult
		switch operation {
		case "step":
			result, err = trainer.Step(ctx, input, target)
		case "from":
			result, err = trainer.StepFrom(ctx, input, upstream)
		default:
			return nil, fmt.Errorf("operation %d %q is unknown", index, operation)
		}
		if err != nil {
			return nil, fmt.Errorf("operation %d %s: %w", index, operation, err)
		}
		if err := auditResultFinite(result); err != nil {
			return nil, fmt.Errorf("operation %d result: %w", index, err)
		}
		predictions, err := trainer.PredictAll(ctx, auditCloneRows(fx.Input))
		if err != nil {
			return nil, fmt.Errorf("operation %d predictions: %w", index, err)
		}
		if err := auditRowsFinite(predictions); err != nil {
			return nil, fmt.Errorf("operation %d predictions: %w", index, err)
		}
		traces = append(traces, trace{Result: result, Snapshot: normalized(trainer.Snapshot()), Predictions: predictions})
	}
	return traces, nil
}

func auditFlatGradient(g learning.Gradient) []float64 {
	values := make([]float64, 0)
	values = append(values, g.Core.Weights...)
	values = append(values, g.Core.Bias...)
	values = append(values, g.Core.LogTau...)
	values = append(values, g.ThetaRaw...)
	values = append(values, g.Encoder...)
	values = append(values, g.Readout...)
	return values
}

func auditAnyNonzero(values []float64) bool {
	for _, value := range values {
		if value != 0 {
			return true
		}
	}
	return false
}

func auditGradientFinite(g learning.Gradient) error {
	for name, values := range map[string][]float64{"weights": g.Core.Weights, "bias": g.Core.Bias, "log_tau": g.Core.LogTau, "initial": g.Core.Initial, "theta_raw": g.ThetaRaw, "encoder": g.Encoder, "readout": g.Readout} {
		for index, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("%s[%d]=%g", name, index, value)
			}
		}
	}
	for row, values := range g.Inputs {
		for column, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("inputs[%d][%d]=%g", row, column, value)
			}
		}
	}
	for row, values := range g.Core.Inputs {
		for column, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("core inputs[%d][%d]=%g", row, column, value)
			}
		}
	}
	return nil
}

func auditRowsFinite(rows [][]float64) error {
	for row, values := range rows {
		for column, value := range values {
			if !auditFiniteFloat(value) {
				return fmt.Errorf("row[%d][%d]=%g", row, column, value)
			}
		}
	}
	return nil
}

func auditResultFinite(result learning.StepResult) error {
	for name, value := range map[string]float64{"loss": result.Loss, "gradient_norm": result.GradientNorm, "update_norm": result.UpdateNorm, "learning_rate": result.LearningRate} {
		if !auditFiniteFloat(value) {
			return fmt.Errorf("%s=%g", name, value)
		}
	}
	return nil
}
