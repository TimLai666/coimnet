# 化學恢復契約稽核

日期：2026-10-14  
儲存庫：`/Users/timlai/Developer/coimnet`  
HEAD：`00bc7016c9380c23ab2154caac10666d798581a5`  
來源指紋基準：`evidence/STA-03/chemical-restore-audit-20261014/source-before.json`（SHA-256：`d6efa8ebe203be8d9355f4a161f9be8cfb7d1641fb06cf78263633e00279d08b`）

## Problem

持續個體的化學恢復必須沿 `RestoreIndividual` → `newChemicalRuntime` → `restoreSourceStates` → `Controller.RestoreState` 建立隔離且可精確接續的狀態。稽核同時檢查來源控制器快照所有權、第二個控制器狀態錯誤的拒絕原子性、先跑再啟用、`ResetNeural` 接續、`SourceStates` 缺省的 legacy 規則，以及 bundle 與單檔 checkpoint 的欄位契約。

## Done

### CONFIRMED P2：`LoadIndividualBundle` 漏掉化學必填欄位存在性檢查

**公開觸發輸入**：

1. 以公開 API 開啟化學層，讓個體進入已執行狀態，並以 `SetResource("energy", 非零有限值)` 宣告資源，或以 `OfferFeedback` 排入合法回饋。`learning/chemistry.go:368-420` 明確把回饋佇列與資源寫入持續 runtime；`modulation/sources.go:160-205` 的 `InternalResource` 會讀取宣告的資源，缺少該資源會回錯。
2. 以 `SaveIndividualBundle` 寫出有效 bundle。該入口只對記憶體快照呼叫 `learning.RestoreIndividual`，再寫入 bundle，位置為 `checkpoint/bundle_kinds.go:58-81`。
3. 在不改變其他宣告、狀態或陣列的情況下，從 bundle 的 `document.json` 刪除 `chemical.state.steps`、`chemical.resources` 或 `chemical.pending_feedback` 其中一個欄位，並同步更新 manifest 的 document bytes 與 SHA-256。這仍是可被 `readBundle` 接受的語法正確、checksum 一致的 bundle。
4. 呼叫 `LoadIndividualBundle`。

**來源證據與影響**：

- `checkpoint/individual.go:261-313` 的 `requireIndividualChemical` 明確規定化學區塊出現時，`config`、`state`、`resources`、`pending_feedback` 都必須存在。註解也說明省略步數或資源會解碼成合法零值，變成不同規則。
- 單檔路徑 `checkpoint/individual.go:114-169` 會在 `decodeStrict` 前以 `requireIndividualFields` 執行上述存在性檢查；`requireIndividualFields` 在 `checkpoint/individual.go:176-224` 呼叫 `requireIndividualChemical`。
- Bundle 路徑 `checkpoint/bundle_kinds.go:84-108` 只經 `readBundle`、`normalizeIndividualSnapshot` 與 `learning.RestoreIndividual`，沒有呼叫等效的原始欄位存在性檢查。`checkpoint/bundle.go:273-333` 的 `readBundle` 只檢查 manifest、document checksum、JSON 唯一鍵、嚴格解碼及大型陣列恢復。
- `checkpoint/individual.go:592-597` 會把被省略的 `resources` 轉成空 map、把被省略的 `pending_feedback` 轉成空 slice。`learning/individual.go:244-274` 再把它們當成合法的空 runtime 狀態接受。
- `chemical.state.steps` 是 `uint64`，被省略後會成為零；`modulation/config.go:261-276` 的 `ValidateState` 只檢查濃度形狀與值，不拒絕零步數。這會把已累積的化學更新計數重設為零，違反 `ENG.md:209` 所定義的來源時鐘與化學更新次數分離且各自保存，以及 `ENG.md:215` 的完整邊界恢復。
- 省略 `resources` 會使依賴該資源的下一個來源釋放讀到缺省空 map。依 `modulation/sources.go:160-205`，結果可能是不同釋放值或明確錯誤。省略 `pending_feedback` 會遺失規格要求保留的回饋佇列，`docs/individual-state.md:64-75` 明確說明該佇列會進快照且化學區塊出現時四個欄位都必填。

因此，合法 bundle 的讀回可以靜默接受欄位遭刪除的文件，回傳與保存前不同的持續化學狀態。這是 bundle 與單檔 checkpoint 的公開恢復契約不一致，且會造成後續 `Advance` 接續結果、錯誤行為或化學計數不同。判定為 P2：觸發需要一個欄位遺失但 manifest 仍被更新的 bundle，然而一旦發生，恢復成功的結果會靜默丟失持續狀態。

**最小修正方向**：在 `LoadIndividualBundle` 的 document 解碼後、任何 normalization 前，加入 bundle document 對應的原始欄位存在性檢查，至少要求化學區塊出現時的 `config`、`state`、`resources`、`pending_feedback`；保留 `source_states` 缺省作為 legacy fresh-source 邊界。不要用 normalization 把缺省的必填欄位轉成空值掩蓋缺失。

### 明確排除的預期行為

- `chemical.source_states` 缺省不是缺陷。`learning/chemical_source_state.go:9-12,44-84` 明確把缺省列表定義為 legacy fresh source，且只重設來源視窗，不改已由呼叫端複製的化學濃度或任何時鐘；這符合 `ENG.md:215`。
- `FreezeChemistry` 是 runtime-only 旗標，`learning/chemistry.go:346-365` 說明快照不保存且恢復後解凍，符合指定規則。
- `ResetNeural` 只替換神經狀態，`learning/individual.go:867-885` 不動化學狀態、來源歷史或化學更新計數，符合 `ENG.md:229`。
- `restoreSourceStates` 先 clone 全部來源，再逐項驗證並只在成功後替換 `r.sources`，`learning/chemical_source_state.go:44-108`；`modulation.Controller.RestoreState` 也在驗證完整視窗後才改 receiver，`modulation/controller_state.go:21-45`。來源狀態所有權與第二控制器錯誤的拒絕原子性未發現可由來源觸發的 P1/P2 缺陷。
- `Snapshot` 深拷貝化學設定、濃度、資源、回饋及來源狀態，`learning/individual.go:399-431`；`newChemicalRuntime` 與 `Controller.Clone` 也建立獨立來源，未發現跨個體或 caller 的可變陣列共享缺陷。

## Changed

| 檔案 | 變更摘要 |
| --- | --- |
| `/Users/timlai/Developer/coimnet/runs/.tmp/chemical-restore-audit-20261014/review/restore-review.md` | 新增本次化學恢復契約稽核報告。 |

## Actions

| 動作 | 對象 | 結果 |
| --- | --- | --- |
| 來源讀取與指紋核對 | 指定 7 個 Go 來源檔、HEAD、`source-before.json` | 只讀完成，指定來源 SHA-256 與基準一致。 |
| Go、測試、正式程式修改 | CoImNet | 未執行、未修改。 |
| Git commit、stash、reset | CoImNet | 未執行。 |

## Verified

- 靜態追蹤 `RestoreIndividual`、`newChemicalRuntime`、`restoreSourceStates`、`Controller.RestoreState`、`Snapshot`、bundle 讀寫與 normalization 的所有權及提交邊界。
- 靜態確認 `LoadIndividualBundle` 沒有呼叫 `requireIndividualFields` 或 bundle 等效存在性檢查，並確認 normalization 與 `RestoreIndividual` 對缺省 `steps`、資源及回饋的接受路徑。
- 靜態確認單檔 `LoadIndividual` 有相同欄位的存在性拒絕路徑，因此缺陷只在 bundle 載入入口。
- 讀取相關既有 tests 作為契約交叉參照，但未執行任何 Go 命令，沒有動態 exit code、runtime log 或新程序逐位結果可報告。

## Notes

- 本報告的 CONFIRMED 判定依公開入口、原始欄位解碼、normalization 與恢復函式的確定性來源路徑，不把既有測試存在視為通過證據。
- 尚未新增失敗測試，因本輪只允許新增本報告且禁止修改測試與正式程式。
- 工作樹原有 `delivery-status.md` 修改、`docs/tickets/97-chemical-restore-composition.md` 及 evidence 目錄未觸碰。

## Next

由 root 在允許的實作階段補上 bundle 缺欄位的失敗測試，加入 bundle 專用的 required-field walk，並驗證缺少 `chemical.state.steps`、`chemical.resources`、`chemical.pending_feedback` 時拒絕且不產生恢復個體；同時保留 `source_states` 缺省的 legacy 測試。

## Source fingerprints

| 檔案 | SHA-256 |
| --- | --- |
| `learning/individual.go` | `531d3ebba6829853a2b8a3eefaf81f744668a281c4afd926170898b5c88486d9` |
| `learning/chemistry.go` | `4e6164cbafd843c56c357558e9b8a580598b607daeccffbfc74a714052a52032` |
| `learning/chemical_source_state.go` | `881a24b1d7be6884d787d6ce05db8019a2bac18b13581ef275b295766924b59e` |
| `learning/individual_chemical_training.go` | `dcf14d76ede60f16e36f48f63fff48124d63c645dbde55355e43b617972f399e` |
| `modulation/controller_state.go` | `c568341acf0662a81ebc8a0ddc09eae04c80edbf001fda4a446e670b6aa2b58f` |
| `checkpoint/individual.go` | `8b26f07b3b8ca656ab4c996d552bc42edbc80abcd278e0317519052471d2ef7a` |
| `checkpoint/bundle_kinds.go` | `83be130d07f6d86a75eecc8ae35e7c876a507f20b112523ab6d79ba5cbfb52` |
| `checkpoint/bundle.go` | `cf12e264c8101e47f5a65f360d0fa5f98335bdfc3765aa6bd8a987961b19754f` |
| `modulation/config.go` | `888441fa39463afe1afe0fb28c8e008d23c55f5e6b8e6aab171e4fd434928a01` |
| `modulation/sources.go` | `5280342db13372aff9ec3f3f540961135e762d97f0af4821a47e6986b85883af` |

CONFIRMED P1：無。  
CONFIRMED P2：1 項，見上方 bundle 化學必填欄位存在性檢查缺口。  
NEEDS INVESTIGATION：動態重現與正式修正後的完整驗證尚未執行，原因是本輪明確禁止執行 Go 並限制只能新增本報告。

Skills：無
