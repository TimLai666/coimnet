package main

import (
	"context"
	"encoding/json"
	"os"

	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/experiment"
	"github.com/TimLai666/coimnet/learning"
)

func main() {
	var reports []experiment.EvaluationReport
	for k := 0; k < 64; k++ {
		width := []int{1, 2, 3, 5}[k%4]
		readout, target := make([]float64, width), make([]float64, width)
		for j := range readout {
			readout[j] = .37 + .13*float64(j)
			target[j] = -.31 + .017*float64(k) - .13*float64(j)
		}
		config := learning.Config{Dynamics: dynamics.Config{Nodes: 1, DT: .5, Activation: "tanh"}, InputSize: 1, OutputSize: width, InputNodes: []int{0}, ReadoutNodes: []int{0}}
		params := learning.Parameters{Core: dynamics.Parameters{Bias: []float64{.1}, LogTau: []float64{.2}}, Encoder: []float64{.3}, Readout: readout}
		ind, err := learning.NewIndividual(config, params, learning.DefaultOptions(), []float64{float64(k)/100 - .3})
		if err != nil {
			panic(err)
		}
		e := experiment.AdaptiveEvaluation{Mode: experiment.EvaluationModeFixed, Scoring: []experiment.EvaluationItem{
			{ID: "first", Input: [][]float64{{-2 + .173*float64(k)}, {.123}}, Target: target},
			{ID: "second", Input: [][]float64{{.3}, {-.79}}, Target: target},
		}}
		report, err := experiment.RunAdaptiveEvaluation(context.Background(), ind, e)
		if err != nil {
			panic(err)
		}
		reports = append(reports, report)
	}
	if err := json.NewEncoder(os.Stdout).Encode(reports); err != nil {
		panic(err)
	}
}
