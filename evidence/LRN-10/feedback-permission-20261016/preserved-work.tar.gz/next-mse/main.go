package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"math/big"
	"os"

	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/experiment"
	"github.com/TimLai666/coimnet/learning"
)

func main() {
	var rows []map[string]any
	for _, value := range []float64{.5, 1e154} {
		config := learning.Config{
			Dynamics: dynamics.Config{Nodes: 1, DT: 1, Activation: "tanh"},
			InputSize: 1, OutputSize: 2, InputNodes: []int{0}, ReadoutNodes: []int{0},
		}
		parameters := learning.Parameters{
			Core: dynamics.Parameters{Bias: []float64{0}, LogTau: []float64{0}},
			Encoder: []float64{1}, Readout: []float64{0, 0},
		}
		ind, err := learning.NewIndividual(config, parameters, learning.DefaultOptions(), []float64{0})
		if err != nil {
			panic(err)
		}
		e := experiment.AdaptiveEvaluation{Mode: experiment.EvaluationModeFixed,
			Scoring: []experiment.EvaluationItem{{ID: "two-output", Input: [][]float64{{0}}, Target: []float64{value, value}}},
		}
		if err := e.Validate(); err != nil {
			panic(err)
		}
		report, err := experiment.RunAdaptiveEvaluation(context.Background(), ind, e)
		if err != nil {
			panic(err)
		}
		v := new(big.Rat).SetFloat64(value)
		want, _ := new(big.Rat).Mul(v, v).Float64()
		_, marshalErr := json.Marshal(report)
		rows = append(rows, map[string]any{
			"target": value, "valid_declaration": true, "output": report.Scores[0].Output,
			"reported_mse": fmt.Sprint(report.Scores[0].MSE), "reported_finite": !math.IsInf(report.Scores[0].MSE, 0),
			"exact_reference_rounded": want, "json_error": fmt.Sprint(marshalErr),
		})
	}
	if err := json.NewEncoder(os.Stdout).Encode(rows); err != nil {
		panic(err)
	}
}
