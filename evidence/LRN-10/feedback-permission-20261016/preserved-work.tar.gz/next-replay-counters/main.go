package main

import (
	"encoding/json"
	"os"

	"github.com/TimLai666/coimnet/replay"
)

func main() {
	var rows []map[string]any
	for _, tc := range []struct {
		name     string
		capacity int
		sampling string
		added    int
	}{
		{"empty", 2, replay.SamplingUniform, 0},
		{"one-seen", 2, replay.SamplingUniform, 1},
		{"fifo-capacity-one", 1, replay.SamplingUniform, 3},
		{"time-balanced-capacity-two", 2, replay.SamplingTimeBalanced, 3},
	} {
		b := replay.Buffer{Capacity: tc.capacity, Sampling: tc.sampling, Eviction: replay.EvictionFIFO,
			Privacy: replay.PrivacyPolicy{StoreRaw: true, Retention: replay.RetentionKeepUntilEvicted}}
		store, err := replay.New(b)
		if err != nil {
			panic(err)
		}
		for i := range tc.added {
			if err := store.Add(replay.Experience{TaskID: "a", Step: uint64(i), Input: [][]float64{{1}}, Target: [][]float64{{0}}, Split: replay.SplitTrain, Weight: 1}); err != nil {
				panic(err)
			}
		}
		s := store.State()
		s.Draws = 1
		_, err = replay.Restore(b, s)
		rows = append(rows, map[string]any{"case": tc.name, "accepted": err == nil, "seen": s.Seen, "draws": s.Draws})
	}
	if err := json.NewEncoder(os.Stdout).Encode(rows); err != nil {
		panic(err)
	}
}
