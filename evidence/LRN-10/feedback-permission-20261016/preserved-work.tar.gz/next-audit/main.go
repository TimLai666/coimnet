package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/experiment"
	"github.com/TimLai666/coimnet/learning"
	"github.com/TimLai666/coimnet/plasticity"
	"github.com/TimLai666/coimnet/replay"
)

func must(err error) {
	if err != nil {
		panic(err)
	}
}

func individual() *learning.Individual {
	c := learning.Config{Dynamics: dynamics.Config{Nodes: 2, Sources: []int{0}, Targets: []int{1}, DT: 1, Activation: "tanh"}, InputSize: 2, OutputSize: 1, InputNodes: []int{0, 1}, ReadoutNodes: []int{1}}
	p := learning.Parameters{Core: dynamics.Parameters{Weights: []float64{.9}, Bias: []float64{0, 0}, LogTau: []float64{0, 0}}, Encoder: []float64{1, 0, 0, 1}, Readout: []float64{1}}
	a, err := learning.NewIndividual(c, p, learning.DefaultOptions(), []float64{0, 0})
	must(err)
	must(a.EnablePlasticity(plasticity.Config{Edges: []int{0}, Rule: plasticity.Rule{Kind: plasticity.RuleHebbianRate, DecayE: .5, DecayP: .5, PlasticMax: 8, WMin: .0625}}))
	return a
}

func main() {
	var results []map[string]any
	for _, permission := range []string{"none", "available-only", "score", "correctness"} {
		for _, target := range []float64{.5, 100} {
			a := individual()
			var available, allowed []string
			if permission == "available-only" || permission == "score" {
				available = []string{"score"}
			}
			if permission == "score" {
				allowed = []string{"score"}
			}
			if permission == "correctness" {
				available, allowed = []string{"correctness"}, []string{"correctness"}
			}
			e := experiment.AdaptiveEvaluation{Mode: experiment.EvaluationModeAdaptive, FeedbackAvailable: available, Adaptation: []experiment.EvaluationItem{{ID: "adapt", Input: [][]float64{{2, 2}, {2, 2}, {2, 2}}, Target: []float64{target}, AllowedFeedback: allowed}}, Scoring: []experiment.EvaluationItem{{ID: "score", Input: [][]float64{{2, 2}}, Target: []float64{0}}}}
			valid := e.Validate() == nil
			before := a.Snapshot()
			r, err := experiment.RunAdaptiveEvaluation(context.Background(), a, e)
			must(err)
			results = append(results, map[string]any{"kind": "feedback-permission", "permission": permission, "target": target, "valid": valid, "fast_before": before.Plastic.State.Plastic, "fast_after": a.Snapshot().Plastic.State.Plastic, "output": r.Scores[0].Output})
		}
	}
	b := replay.Buffer{Capacity: 2, Sampling: replay.SamplingUniform, Eviction: replay.EvictionFIFO, Privacy: replay.PrivacyPolicy{StoreRaw: false, Retention: replay.RetentionKeepUntilEvicted}}
	_, err := replay.Restore(b, replay.State{SchemaVersion: replay.StateVersion, Seen: 1, Items: []replay.Experience{{TaskID: "task", Split: replay.SplitTrain, Weight: 1, Raw: false, InputHash: strings.Repeat("z", 64), TargetHash: strings.Repeat("z", 64)}}})
	results = append(results, map[string]any{"kind": "non-hex-sha256", "accepted": err == nil, "error": fmt.Sprint(err)})
	b.Eviction = replay.EvictionReservoir
	store, err := replay.New(b)
	must(err)
	for k := range 2 {
		must(store.Add(replay.Experience{TaskID: "task", Step: uint64(k), Input: [][]float64{{float64(k)}}, Target: [][]float64{{0}}, Weight: 1, Split: replay.SplitTrain}))
	}
	s := store.State()
	s.Seen = 3
	_, err = replay.Restore(b, s)
	results = append(results, map[string]any{"kind": "missing-reservoir-draw", "seen": s.Seen, "draws": s.Draws, "accepted": err == nil, "error": fmt.Sprint(err)})
	must(json.NewEncoder(os.Stdout).Encode(results))
}
