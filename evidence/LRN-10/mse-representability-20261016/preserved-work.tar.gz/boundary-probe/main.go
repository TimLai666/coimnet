package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"math/big"
	"os"
	"reflect"

	"github.com/TimLai666/coimnet/dynamics"
	"github.com/TimLai666/coimnet/experiment"
	"github.com/TimLai666/coimnet/learning"
)

func main() {
	cases := []struct {
		name   string
		target []float64
	}{
		{"normal", []float64{.5, .5}},
		{"sum-overflow", []float64{1e154, 1e154}},
		{"square-overflow", []float64{1.4e154, 0}},
		{"three-output-square-overflow", []float64{1.6e154, 0, 0}},
		{"lost-underflow-contribution", []float64{math.Ldexp(1, -537), math.Ldexp(1, -538)}},
		{"unrepresentable", []float64{math.MaxFloat64, math.MaxFloat64}},
	}
	var rows []map[string]any
	for _, c := range cases {
		config := learning.Config{
			Dynamics:  dynamics.Config{Nodes: 1, DT: 1, Activation: "tanh"},
			InputSize: 1, OutputSize: len(c.target), InputNodes: []int{0}, ReadoutNodes: []int{0},
		}
		parameters := learning.Parameters{
			Core:    dynamics.Parameters{Bias: []float64{0}, LogTau: []float64{0}},
			Encoder: []float64{1}, Readout: make([]float64, len(c.target)),
		}
		ind, err := learning.NewIndividual(config, parameters, learning.DefaultOptions(), []float64{0})
		if err != nil {
			panic(err)
		}
		e := experiment.AdaptiveEvaluation{Mode: experiment.EvaluationModeFixed,
			Scoring: []experiment.EvaluationItem{{ID: c.name, Input: [][]float64{{0}}, Target: c.target}},
		}
		if err := e.Validate(); err != nil {
			panic(err)
		}
		var exact, term big.Rat
		for _, target := range c.target {
			term.SetFloat64(target)
			term.Mul(&term, &term)
			exact.Add(&exact, &term)
		}
		exact.Quo(&exact, big.NewRat(int64(len(c.target)), 1))
		want, _ := exact.Float64()
		report, err := experiment.RunAdaptiveEvaluation(context.Background(), ind, e)
		_, marshalErr := json.Marshal(report)
		row := map[string]any{
			"case": c.name, "target": c.target, "valid_declaration": true,
			"error": fmt.Sprint(err), "zero_report": reflect.DeepEqual(report, experiment.EvaluationReport{}),
			"reference": fmt.Sprint(want), "reference_bits": math.Float64bits(want),
			"reference_finite": !math.IsInf(want, 0), "json_error": fmt.Sprint(marshalErr),
		}
		if len(report.Scores) > 0 {
			row["reported_mse"] = fmt.Sprint(report.Scores[0].MSE)
			row["reported_bits"] = math.Float64bits(report.Scores[0].MSE)
			row["output"] = report.Scores[0].Output
		}
		rows = append(rows, row)
	}
	if err := json.NewEncoder(os.Stdout).Encode(rows); err != nil {
		panic(err)
	}
}
