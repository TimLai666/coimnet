package categorical

// expDifference represents exp(left-right) as mantissa*2^exponent.
// Callers provide finite operands with left <= right. Zero is returned only
// when no finite factor and MaxInt64-class aggregate can rescue the value.
func expDifference(left, right float64) (float64, int) {
	return 0, 0
}
