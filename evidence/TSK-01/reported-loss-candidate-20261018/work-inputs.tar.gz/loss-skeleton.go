package categorical

import "errors"

// Loss is the scalar-loss validation skeleton; no production implementation.
func Loss(logits []float64, target int, factor float64) (float64, error) {
	return 0, errors.New("categorical: scalar loss skeleton not implemented")
}
